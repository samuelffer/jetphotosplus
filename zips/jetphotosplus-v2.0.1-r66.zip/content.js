/*
 * JetPhotos+
 * -----------------------------------
 * Criado por: Samuel Ferreira
 * Objetivo: ajudar a curtir manualmente (com um clique) as fotos que ainda
 * faltam curtir no perfil de um fotógrafo no JetPhotos — útil para grupos
 * de spotting cuja regra é "curtir todas as fotos dos membros".
 *
 * Importante: este script NÃO curte nada sozinho em segundo plano. Ele só
 * facilita a ação quando VOCÊ clica no botão "Curtir faltantes desta página",
 * dentro da sua própria sessão logada no navegador.
 */

(function () {
  'use strict';

  // Orion e Firefox podem expor a API WebExtensions no namespace `browser`,
  // enquanto Chrome e derivados tradicionalmente usam `chrome`. Mantemos a
  // API nativa quando disponível e só recorremos ao armazenamento da origem
  // como fallback, sem alterar o caminho normal dos navegadores convencionais.
  const JP_WEBEXT = globalThis.browser || globalThis.chrome || null;
  const JP_USE_BROWSER_PROMISES = Boolean(globalThis.browser && globalThis.browser !== globalThis.chrome);
  const JP_LOCAL_FALLBACK_PREFIX = 'jpplus-webext-fallback:';

  function readLocalFallback(keys) {
    const result = {};
    const list = Array.isArray(keys) ? keys : [keys];
    try {
      for (const key of list) {
        const raw = localStorage.getItem(`${JP_LOCAL_FALLBACK_PREFIX}${key}`);
        if (raw !== null) result[key] = JSON.parse(raw);
      }
    } catch (_) {}
    return result;
  }

  function writeLocalFallback(items) {
    try {
      for (const [key, value] of Object.entries(items || {})) {
        localStorage.setItem(`${JP_LOCAL_FALLBACK_PREFIX}${key}`, JSON.stringify(value));
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  function getExtensionStorage(keys) {
    const storage = JP_WEBEXT?.storage?.local;
    if (!storage?.get) return Promise.resolve(readLocalFallback(keys));
    if (JP_USE_BROWSER_PROMISES) {
      try {
        return Promise.resolve(storage.get(keys)).catch(() => readLocalFallback(keys));
      } catch (_) {
        return Promise.resolve(readLocalFallback(keys));
      }
    }
    return new Promise(resolve => {
      try {
        storage.get(keys, result => {
          try {
            if (JP_WEBEXT.runtime?.lastError) { resolve(readLocalFallback(keys)); return; }
          } catch (_) { resolve(readLocalFallback(keys)); return; }
          resolve(result || readLocalFallback(keys));
        });
      } catch (_) {
        resolve(readLocalFallback(keys));
      }
    });
  }

  function setExtensionStorage(items) {
    const storage = JP_WEBEXT?.storage?.local;
    if (!storage?.set) {
      writeLocalFallback(items);
      return Promise.resolve();
    }
    if (JP_USE_BROWSER_PROMISES) {
      try {
        return Promise.resolve(storage.set(items)).catch(() => { writeLocalFallback(items); });
      } catch (_) {
        writeLocalFallback(items);
        return Promise.resolve();
      }
    }
    return new Promise(resolve => {
      try {
        storage.set(items, () => {
          let failed = false;
          try { failed = Boolean(JP_WEBEXT.runtime?.lastError); } catch (_) { failed = true; }
          if (failed) writeLocalFallback(items);
          resolve();
        });
      } catch (_) {
        writeLocalFallback(items);
        resolve();
      }
    });
  }

  function sendExtensionMessage(message) {
    const runtime = JP_WEBEXT?.runtime;
    if (!runtime?.sendMessage) return Promise.resolve(null);
    if (JP_USE_BROWSER_PROMISES) {
      try { return Promise.resolve(runtime.sendMessage(message)).catch(() => null); }
      catch (_) { return Promise.resolve(null); }
    }
    return new Promise(resolve => {
      try {
        runtime.sendMessage(message, response => {
          try {
            if (runtime.lastError) { resolve(null); return; }
          } catch (_) { resolve(null); return; }
          resolve(response || null);
        });
      } catch (_) { resolve(null); }
    });
  }

  function getExtensionURL(path) {
    try { return JP_WEBEXT?.runtime?.getURL?.(path) || ''; }
    catch (_) { return ''; }
  }

  // ---------------------------------------------------------------------
  // CONFIG: seletores possíveis do botão de Like e de estado "já curtido".
  // O JetPhotos costuma usar um link com ícone thumbs-up. Depois de
  // curtido, normalmente troca de ícone/classe. Se a detecção não bater
  // 100% no seu login, me avise (inspecionar elemento do botão já
  // curtido) que eu ajusto os seletores/hints abaixo.
  // ---------------------------------------------------------------------
  const LIKED_HINTS = ['liked', 'is-liked', 'thumbs-up-blue', 'thumbs-up-filled', 'unlike'];

  // ---------------------------------------------------------------------
  // Injeta o hook de rede (content-hook.js) no MUNDO DA PÁGINA. Precisa ser
  // uma <script src> porque cada mundo (isolado vs. página) tem seu próprio
  // window.fetch/XHR — sem isso não dá pra saber se um like realmente teve
  // sucesso no servidor. Feito via tag em vez de "world":"MAIN" no manifest
  // pra manter compatibilidade com versões mais antigas do Firefox.
  // ---------------------------------------------------------------------
  function injectNetworkHook() {
    try {
      const script = document.createElement('script');
      script.src = getExtensionURL('content-hook.js');
      if (!script.src) return;
      script.onload = () => script.remove();
      (document.head || document.documentElement).appendChild(script);
    } catch (error) {
      console.error('[JetPhotos+] Falha ao injetar o hook de rede (a sincronia de likes fica limitada ao que o próprio site mostrar no DOM):', error);
    }
  }
  injectNetworkHook();

  // Chaves usadas no chrome.storage.local para lembrar as preferências
  // do usuário entre sessões/páginas.
  const STORAGE_KEY_SITE_DARK_MODE = 'jpSiteDarkMode'; // boolean, padrão false (EXPERIMENTAL)
  const STORAGE_KEY_QUEUE_ESTIMATOR_ENABLED = 'jpQueueEstimatorEnabled'; // boolean, padrão true (EXPERIMENTAL)
  const STORAGE_KEY_LANGUAGE = 'jpLanguage'; // 'pt-BR' | 'en'

  // ---------------------------------------------------------------------
  // Preload anti-FOUC: evita o "flash" do tema claro original do JetPhotos
  // ao trocar de página com o modo escuro do site ligado.
  //
  // Antes, o content.js só rodava em "document_idle" (depois que a página
  // já tinha sido pintada no tema claro) e só então lia o storage e
  // aplicava applySiteDarkMode() — daí o flash. Agora o manifest.json roda
  // o script em "document_start" (o mais cedo possível) e, aqui em cima,
  // fazemos uma checagem rápida e isolada: se o modo escuro estiver ligado,
  // escondemos a página (fundo escuro neutro + body invisível) até o
  // restante do script (init() -> applySiteDarkMode()) aplicar o tema.
  // Um timeout de segurança garante que a página nunca
  // fique escondida por muito tempo, mesmo se algo falhar.
  // ---------------------------------------------------------------------
  const PRELOAD_HIDE_CLASS = 'jp-dark-preload-hide';
  const PRELOAD_HIDE_STYLE_ID = 'jp-dark-preload-style';
  const PRELOAD_SAFETY_MS = 500;
  let preloadHideRemoved = false;

  function injectPreloadHideStyle() {
    if (document.getElementById(PRELOAD_HIDE_STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = PRELOAD_HIDE_STYLE_ID;
    style.textContent = `
      html.${PRELOAD_HIDE_CLASS} { background: #202124 !important; }
      html.${PRELOAD_HIDE_CLASS} body { visibility: hidden !important; }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  // Chamado depois que applySiteDarkMode() já aplicou o tema (ou pelo
  // timeout de segurança). Idempotente: pode ser chamado mais de uma vez
  // sem problema.
  function removePreloadHide() {
    if (preloadHideRemoved) return;
    preloadHideRemoved = true;
    document.documentElement.classList.remove(PRELOAD_HIDE_CLASS);
    const style = document.getElementById(PRELOAD_HIDE_STYLE_ID);
    if (style) style.remove();
  }

  (function preloadDarkModeCheck() {
    try {
      getExtensionStorage([STORAGE_KEY_SITE_DARK_MODE]).then(result => {
        if (result[STORAGE_KEY_SITE_DARK_MODE] === true) {
          injectPreloadHideStyle();
          document.documentElement.classList.add(PRELOAD_HIDE_CLASS);
        }
      });
    } catch (err) {
      if (!isContextInvalidatedError(err)) throw err;
    }
    // Rede de segurança: nunca deixa a página escondida por mais que isso,
    // mesmo se o storage.get() nunca responder ou o init() falhar.
    setTimeout(removePreloadHide, PRELOAD_SAFETY_MS);
  })();

  // URL de doação (provisória: repositório). Troque pela página definitiva
  // (Ko-fi, Apoia.se, Pix...) quando ela existir.
  const DONATE_URL = 'https://samuelffer.github.io/jetphotosplus/doar.html';
  const I18N = {
    'pt-BR': {
      settings: 'Configurações', close: 'Fechar',
      viewReleases: 'Ver novidades', reportIssue: 'Reportar um problema', aboutJetPhotosPlus: 'Sobre o JetPhotos+', donate: 'Doar',
      analyzing: 'Analisando página...',
      likeMissing: 'Curtir faltantes',
      missing: 'faltando',
      allLikedToast: 'Todas as fotos da página já estão curtidas',
      settingsGeneral: 'Geral',
      experimental: 'Experimental',
      siteDarkMode: 'Modo escuro (beta)',
      siteDarkModeHelp: 'Escurece o JetPhotos e também a interface da extensão (painel, submenu e widget). Fotos e cores de marca não são alteradas.',
      queueEstimator: 'Estimador de dias na fila (beta)',
      queueEstimatorHelp: 'Estimativa de quanto falta pra sua foto ser avaliada, em queue.php. Requer recarregar a página após mudar.',
      language: 'Idioma',
      languageHelp: 'Escolha o idioma da extensão.',
      portugueseBrazil: 'Português (Brasil)', english: 'English',
      queueEstimate: 'Estimativa da fila JetPhotos+',
      likeWidgetLabel: 'JETPHOTOS+ · Likes',
      screenedToday: 'Analisadas hoje:',
      dailyAverage: 'Média diária:',
      estimatedQueueTime: 'Tempo estimado:',
      lastCollection: 'Última coleta:',
      collectingHistory: 'Coletando...',
      noHistoryNote: 'A média será calculada após o primeiro dia concluído.',
      avgClosed: (n) => `Média dos últimos ${n} dia${n === 1 ? '' : 's'} concluído${n === 1 ? '' : 's'}`,
      collectNow: 'Coletar agora', collecting: 'Coletando...',
      noPhotosQueue: 'Nenhuma foto sua na fila no momento.',
      photosAhead: (n, eta) => `${n.toLocaleString('pt-BR')} fotos à frente — ${eta}`,
      noRate: 'sem dados de ritmo ainda',
      queueReadError: 'Não consegui ler os dados da fila nesta página.',
      buildingHistory: 'Ainda estou construindo o histórico automático do ritmo da fila. Por enquanto, uso o maior Total Screened observado hoje; depois de alguns dias, passo a usar a média dos dias fechados.',
      rateToday: 'maior Total Screened observado hoje',
      rateClosed: (n) => `média dos últimos ${n} dia${n === 1 ? '' : 's'} fechados`,
      ratePeriod: 'Total Screened de hoje (ainda calibrando histórico)',
      rateSnapshot: (n) => `${n} dia${n === 1 ? '' : 's'} de fila acompanhados`,
      rateFallback: 'estimativa provisória enquanto calibro',
      currentRate: (n, basis) => `Ritmo atual: <b>~${Math.round(n).toLocaleString('pt-BR')} fotos/dia</b>${basis ? ` (${basis})` : ''}`,
      generalEta: (eta) => `Estimativa geral de dias em espera: <b>${eta}</b>`,
      queueTotal: (n) => `Fila total no site: ${n.toLocaleString('pt-BR')} fotos.`,
      timezoneAhead: (n) => ` Fuso do site ${Math.abs(n)} dia(s) à frente do seu computador.`,
      timezoneBehind: (n) => ` Fuso do site ${Math.abs(n)} dia(s) atrás do seu computador.`,
      aroundDate: 'por volta de',
      trackedDays: (n) => `${n} dia${n === 1 ? '' : 's'} acompanhado${n === 1 ? '' : 's'}`,
      historyData: 'Histórico da fila',
      historyDataHelp: 'Backup do ritmo da fila (fotos analisadas por dia). Importar mescla com o que já existe, sem apagar.',
      exportHistory: 'Exportar histórico',
      importHistory: 'Importar histórico',
      historyExported: 'Histórico exportado.',
      historyImported: (n) => `Histórico importado: ${n} dia${n === 1 ? '' : 's'}.`,
      historyImportFail: 'Falha ao importar o arquivo.',
      estimatedReview: 'Estimativa de análise:',
    },
    en: {
      settings: 'Settings', close: 'Close', viewReleases: "See what's new", reportIssue: 'Report an issue', aboutJetPhotosPlus: 'About JetPhotos+', donate: 'Donate', analyzing: 'Analyzing page...',
      likeMissing: 'Like missing photos',
      missing: 'missing',
      allLikedToast: 'All photos on this page are already liked',
      experimental: 'Experimental', settingsGeneral: 'General', siteDarkMode: 'Site dark mode (beta)', siteDarkModeHelp: 'Darkens JetPhotos backgrounds and light text. Photos and brand colors are not changed.',
      queueEstimator: 'Queue days estimator (beta)', queueEstimatorHelp: 'Estimates how long your photo may take to be reviewed on queue.php. Reload the page after changing.',
      language: 'Language', languageHelp: 'Choose the extension language.', portugueseBrazil: 'Português (Brasil)', english: 'English',
      queueEstimate: 'Queue estimate', likeWidgetLabel: 'JETPHOTOS+ · Likes', screenedToday: 'Screened today:', dailyAverage: 'Daily average:', estimatedQueueTime: 'Estimated time:', lastCollection: 'Last collection:',
      collectingHistory: 'Collecting...', noHistoryNote: 'The average will be calculated after the first completed day.',
      avgClosed: (n) => `Average of the last ${n} completed day${n === 1 ? '' : 's'}`,
      collectNow: 'Collect now', collecting: 'Collecting...', noPhotosQueue: 'You have no photos in the queue right now.',
      photosAhead: (n, eta) => `${n.toLocaleString('en-US')} photos ahead — ${eta}`, noRate: 'no queue rate data yet',
      queueReadError: 'I could not read the queue data on this page.',
      buildingHistory: "I’m still building the automatic queue-rate history. For now, I use the highest Total Screened observed today; after a few days, I’ll use the average of completed days.",
      rateToday: 'highest Total Screened observed today', rateClosed: (n) => `average of the last ${n} completed day${n === 1 ? '' : 's'}`,
      ratePeriod: "today's Total Screened (history still calibrating)", rateSnapshot: (n) => `${n} tracked queue day${n === 1 ? '' : 's'}`, rateFallback: 'provisional estimate while calibrating',
      currentRate: (n, basis) => `Current rate: <b>~${Math.round(n).toLocaleString('en-US')} photos/day</b>${basis ? ` (${basis})` : ''}`,
      generalEta: (eta) => `General waiting estimate: <b>${eta}</b>`, queueTotal: (n) => `Total site queue: ${n.toLocaleString('en-US')} photos.`,
      timezoneAhead: (n) => ` Site time is ${Math.abs(n)} day(s) ahead of your computer.`, timezoneBehind: (n) => ` Site time is ${Math.abs(n)} day(s) behind your computer.`, aroundDate: 'around',
      trackedDays: (n) => `${n} tracked day${n === 1 ? '' : 's'}`,
      historyData: 'Queue history',
      historyDataHelp: 'Backup of queue pace (photos reviewed per day). Import merges with existing data and does not delete it.',
      exportHistory: 'Export history',
      importHistory: 'Import history',
      historyExported: 'History exported.',
      historyImported: (n) => `History imported: ${n} day${n === 1 ? '' : 's'}.`,
      historyImportFail: 'Could not import that file.',
      estimatedReview: 'Estimated review:',
    }
  };

  function t(key, ...args) {
    const lang = currentSettings?.language === 'en' ? 'en' : 'pt-BR';
    const value = I18N[lang][key] ?? I18N['pt-BR'][key] ?? key;
    return typeof value === 'function' ? value(...args) : value;
  }

  const STORAGE_KEY_QUEUE_DAILY_STATS = 'jpQueueDailyStats';
  const QUEUE_RATE_SAMPLE_DAYS = 6;


  // A página pode manter um content script antigo vivo depois que a extensão
  // é recarregada durante o desenvolvimento. Nesse estado, qualquer acesso à
  // API da extensão pode lançar "Extension context invalidated".
  function isExtensionContextAlive() {
    try { return Boolean(JP_WEBEXT?.runtime && JP_WEBEXT.runtime.id); }
    catch (_) { return false; }
  }

  function isContextInvalidatedError(error) {
    return /Extension context invalidated/i.test(String(error?.message || error || ''));
  }

  function isAlreadyLiked(likeAnchor, card) {
    if (!likeAnchor) return false;

    // O JetPhotos atualmente representa o estado de curtida no próprio
    // <a class="social__link social__link--like">. Quando a foto já está
    // curtida, ele adiciona a classe "social__link--active". O ícone
    // thumbs-up-black.svg continua igual nos dois estados, então o src do
    // <img> não deve ser usado para diferenciar Like/Unlike.
    if (likeAnchor.classList?.contains('social__link--active')) return true;

    // Mantém compatibilidade com versões/variações antigas do JetPhotos.
    const ariaPressed = likeAnchor.getAttribute('aria-pressed');
    if (ariaPressed === 'true') return true;
    const dataLiked = likeAnchor.getAttribute('data-liked');
    if (dataLiked === 'true' || dataLiked === '1') return true;

    const html = likeAnchor.outerHTML.toLowerCase();
    if (LIKED_HINTS.some(hint => html.includes(hint))) return true;

    // Bug visual conhecido do JetPhotos: o like é salvo no servidor mas o
    // próprio HTML às vezes não reflete isso (nem na hora, nem depois de um
    // F5). Nossa cache local (ver bloco "Sincronia de likes" abaixo) só tem
    // uma entrada quando o servidor CONFIRMOU sucesso, então é seguro usá-la
    // como fonte de verdade extra e corrigir o ícone na hora.
    const photoId = getPhotoId(likeAnchor, card);
    if (photoId && isPhotoLikedInCache(photoId)) {
      forceLikedVisual(likeAnchor);
      return true;
    }

    return false;
  }

  // =======================================================================
  // SINCRONIA DE LIKES — corrige o bug visual do JetPhotos e garante que
  // o estado "curtido" sobrevive a um F5, tanto pra cliques da extensão
  // quanto pra cliques manuais do usuário.
  //
  // Descoberta-chave (via DevTools): o like/unlike do JetPhotos é uma
  // única requisição XHR pro endpoint
  //   PostHandler.php?addFavorite=<ID>&doAjax=true    (curtir)
  //   PostHandler.php?removeFavorite=<ID>&doAjax=true (descurtir)
  // e <ID> é EXATAMENTE o mesmo número que já aparece no HTML em
  // data-photo="<ID>" (card) / data-id="<ID>" (wrapper .social). Ou seja,
  // não precisamos mais adivinhar qual clique corresponde a qual resposta
  // (nada de fila/FIFO): a própria URL da requisição já entrega o ID da
  // foto, e a gente casa direto com o elemento certo na página.
  //
  // Fluxo:
  //   1. content-hook.js (mundo da página) intercepta fetch/XHR, extrai
  //      {id, action} da URL e confirma sucesso lendo a resposta (o
  //      PostHandler retorna o texto "true"/"false"), avisando o
  //      content.js via CustomEvent('jpplus-like-net-result').
  //   2. Aqui a gente só reage ao evento: se foi "add" e o servidor
  //      confirmou, persiste o ID no cache local e força a classe que o
  //      próprio JetPhotos usa pra pintar o ícone/rótulo de curtido
  //      (".social__link--active") — a CSS do site já sabe estilizar isso
  //      em qualquer tema, então não reinventamos cor. Se for "remove"
  //      confirmado (o usuário descurtiu manualmente), fazemos o inverso.
  //      Se o servidor não confirmar (falha real), NADA muda — a foto
  //      continua "faltante" e será re-tentada normalmente.
  // =======================================================================

  const LIKE_CACHE_KEY = 'jpPlusLikedPhotoIds_v1';
  const LIKE_CACHE_MAX = 20000; // teto de segurança pra não crescer sem fim em contas com muitos likes
  let likeCache = null; // carregada 1x sob demanda e mantida em memória

  function loadLikeCache() {
    try {
      const raw = localStorage.getItem(LIKE_CACHE_KEY);
      const parsed = raw ? JSON.parse(raw) : {};
      return (parsed && typeof parsed === 'object') ? parsed : {};
    } catch (_) {
      return {}; // localStorage corrompido/bloqueado (ex: modo privado) — segue sem cache, sem quebrar nada
    }
  }

  function getLikeCache() {
    if (!likeCache) likeCache = loadLikeCache();
    return likeCache;
  }

  function saveLikeCache() {
    try {
      const cache = getLikeCache();
      const keys = Object.keys(cache);
      if (keys.length > LIKE_CACHE_MAX) {
        // Poda as entradas mais antigas (menor timestamp), preservando as
        // curtidas mais recentes. São só IDs numéricos (chave) + timestamp
        // (valor), então mesmo 20 mil entradas ocupam poucos KB — não pesa
        // no navegador mesmo curtindo centenas/milhares de fotos.
        keys.sort((a, b) => cache[a] - cache[b]);
        keys.slice(0, keys.length - LIKE_CACHE_MAX).forEach(k => delete cache[k]);
      }
      localStorage.setItem(LIKE_CACHE_KEY, JSON.stringify(cache));
    } catch (_) { /* quota cheia ou storage bloqueado: falha silenciosa, não é crítico */ }
  }

  function isPhotoLikedInCache(photoId) {
    return Boolean(photoId) && Boolean(getLikeCache()[photoId]);
  }

  function markPhotoLikedInCache(photoId) {
    if (!photoId) return;
    const cache = getLikeCache();
    if (cache[photoId]) return; // já registrada, evita parse/write à toa
    cache[photoId] = Date.now();
    saveLikeCache();
  }

  function unmarkPhotoLikedInCache(photoId) {
    if (!photoId || !(photoId in getLikeCache())) return;
    delete likeCache[photoId];
    saveLikeCache();
  }

  // Extrai o ID da foto a partir do card/âncora. Prioriza os atributos
  // data-photo/data-id (o mesmo valor usado nas URLs addFavorite/
  // removeFavorite — ver bloco acima), com um fallback pro link /photo/<id>
  // caso algum layout não tenha esses atributos.
  function getPhotoId(anchor, card) {
    // Seletor restrito de propósito: NÃO usa "[data-id]" genérico. Um
    // seletor genérico faria closest() poder subir a árvore e casar com o
    // data-id de um componente qualquer alheio à foto (carrossel, anúncio,
    // widget de terceiros) em algum layout diferente do padrão de busca —
    // aí a foto ficaria associada a um ID errado, e se esse ID já existisse
    // no cache de likes (por pertencer de verdade a OUTRA foto), a extensão
    // mostraria essa foto como "curtida" sem realmente estar. Por isso só
    // aceita os dois contêineres que o próprio JetPhotos usa de fato pra
    // essa informação: o card (".result[data-photo]") e o wrapper dos
    // links Album/Like/Share (".social[data-id]").
    const withData = (card || anchor)?.closest?.('.result[data-photo], .social[data-id]');
    const fromData = withData?.dataset?.photo || withData?.dataset?.id;
    if (fromData) return String(fromData);

    const scope = card || anchor;
    const photoLink = scope?.querySelector?.('a[href*="/photo/"]');
    const fromHref = photoLink?.getAttribute('href')?.match(/\/photo\/(\d+)/);
    if (fromHref) return fromHref[1];

    return null;
  }

  // Backstop do verde exato (TESTE): o CSS cobre (quase) toda estrutura,
  // mas o ícone inicial da barrinha do mobile escapa e o site o remonta
  // diferente no toggle — por isso pintar inline aqui garante o tom em
  // qualquer estrutura, nos dois temas. Só img/svg/i (nunca um invólucro
  // que possa conter o rótulo). Idempotente e barato: pode rodar sempre.
  function greenFilterUrl() {
    return document.documentElement.classList.contains(SITE_DARK_HTML_CLASS) ? 'url(#jp-green-dark)' : 'url(#jp-green-light)';
  }

  function paintLikeIconGreen(scope, liked) {
    if (!scope) return;
    const icon = scope.querySelector('img, svg, i');
    if (!icon) return;
    if (liked) {
      icon.style.setProperty('filter', greenFilterUrl(), 'important');
      icon.style.setProperty('opacity', '1', 'important');
    } else {
      icon.style.removeProperty('filter');
      icon.style.removeProperty('opacity');
    }
  }

  function repaintLikeIcons() {
    document.querySelectorAll('a.social__link--like').forEach(anchor => paintLikeIconGreen(anchor, anchor.classList.contains('social__link--active')));
    document.querySelectorAll('.' + MOBILE_LIKE_BTN_CLASS).forEach(btn => paintLikeIconGreen(btn, btn.classList.contains(MOBILE_LIKE_BTN_LIKED_CLASS)));
  }

  function forceLikedVisual(anchor) {
    if (!anchor) return;
    if (!anchor.classList.contains('social__link--active')) {
      anchor.classList.add('social__link--active');
      anchor.setAttribute('aria-pressed', 'true');
    }
    paintLikeIconGreen(anchor, true);
  }

  function revokeLikedVisual(anchor) {
    if (!anchor) return;
    anchor.classList.remove('social__link--active');
    anchor.removeAttribute('aria-pressed');
    paintLikeIconGreen(anchor, false);
  }

  // Aplica o estado confirmado (liked/unliked) direto nos elementos dessa
  // foto, sem varrer a página inteira: mira pelo data-photo/data-id, que é
  // o mesmo ID da resposta de rede. Isso importa porque esta função roda a
  // cada confirmação — durante uma leva em massa, o findPhotoCards()
  // completo aqui dentro significava N varreduras (era parte da lentidão
  // no celular). O querySelectorAll cobre o caso raro da mesma foto
  // aparecer 2x na mesma página. Fotos sem data-photo/data-id (só
  // detectáveis pelo fallback de href) não são pegas aqui, mas o
  // refresh() periódico corrige elas normalmente.
  function syncPhotoVisualById(photoId, liked) {
    if (!photoId) return;
    const id = CSS.escape(String(photoId));
    document.querySelectorAll(`.result[data-photo="${id}"], .social[data-id="${id}"]`).forEach(scope => {
      const img = scope.querySelector('img[alt="Like"], img[title="Like"]');
      const anchor = img?.closest('a');
      // O closest() pode subir pra fora do scope se o img não estiver num
      // link — nesse caso a âncora não é o Like desta foto, então pula.
      if (anchor && scope.contains(anchor)) {
        if (liked) forceLikedVisual(anchor); else revokeLikedVisual(anchor);
      }
      scope.querySelectorAll('.' + MOBILE_LIKE_BTN_CLASS).forEach(btn => applyMobileButtonState(btn, liked));
    });
  }

  function handleLikeNetResult(event) {
    const { id, action, ok } = event.detail || {};
    if (!id || !action) return; // sem ID/ação reconhecidos: não dá pra casar com nenhuma foto

    if (ok) {
      if (action === 'add') {
        markPhotoLikedInCache(id);
        syncPhotoVisualById(id, true);
      } else if (action === 'remove') {
        unmarkPhotoLikedInCache(id);
        syncPhotoVisualById(id, false);
      }
    } else {
      // O servidor recusou (ou a rede falhou): desfaz a UI otimista que o
      // toque aplicou na hora — sem isso o joinha ficaria "curtido" pra
      // sempre numa foto que na verdade não foi curtida.
      if (action === 'add') {
        unmarkPhotoLikedInCache(id);
        syncPhotoVisualById(id, false);
      } else if (action === 'remove') {
        markPhotoLikedInCache(id);
        syncPhotoVisualById(id, true);
      }
    }

    // Num clique avulso, atualiza contador/realce na hora, sem esperar o
    // debounce. Durante a leva em massa o refresh() se auto-pula (ver
    // refresh) e o settle acontece uma vez só no final — sem isso seriam N
    // varreduras completas do DOM, uma por foto, que é o que travava o
    // celular.
    refresh();
  }

  let likeSyncWired = false;
  function wireLikeSync() {
    if (likeSyncWired) return;
    likeSyncWired = true;
    window.addEventListener('jpplus-like-net-result', handleLikeNetResult);
  }

  // Detecta em qual página estamos pra mostrar um rótulo de contexto no
  // painel. A detecção de fotos (findPhotoCards) já é genérica o bastante
  // pra funcionar em qualquer uma delas sem mudar nada — mudei só o rótulo.
  function getPageContextLabel() {
    const path = location.pathname;
    if (path.startsWith('/members/queue.php')) return currentSettings?.language === 'en' ? 'Queue status' : 'Fila de avaliação';
    if (path.startsWith('/photographer')) return currentSettings?.language === 'en' ? 'Photographer profile' : 'Perfil do fotógrafo';
    if (path.startsWith('/new')) return currentSettings?.language === 'en' ? 'Recent photos' : 'Fotos recentes';
    if (path.startsWith('/showphotos.php')) return currentSettings?.language === 'en' ? 'Search results' : 'Resultados de busca';
    if (path.startsWith('/top')) return currentSettings?.language === 'en' ? 'Most popular today' : 'Mais populares hoje';
    if (/^\/photo\/\d+/.test(path)) return currentSettings?.language === 'en' ? 'Individual photo' : 'Foto individual';
    if (path === '/photo' || path.startsWith('/photo?')) return currentSettings?.language === 'en' ? 'New registrations' : 'Novos registros';
    if (/^\/group\/\d+\/photos/.test(path)) return currentSettings?.language === 'en' ? 'Group photos' : 'Fotos do grupo';
    return null;
  }

  function findPhotoCards() {
    // Cada foto no listing tem um bloco com a imagem + os links Album/Like/Share.
    // Usamos o ícone "Like" como âncora e subimos até o container do card.
    // O Set evita contar duas vezes a mesma âncora caso o JetPhotos tenha
    // mais de um elemento visual apontando para o mesmo Like.
    const likeImgs = document.querySelectorAll('img[alt="Like"], img[title="Like"]');
    const cards = [];
    const seenAnchors = new Set();
    const seenPhotoIds = new Set();
    likeImgs.forEach(img => {
      const anchor = img.closest('a');
      if (!anchor || seenAnchors.has(anchor)) return;
      seenAnchors.add(anchor);

      // O JetPhotos renderiza os dois layouts (desktop e mobile) no mesmo
      // HTML e alterna qual aparece via classe (".desktop-only"/".mobile-only"),
      // escondendo o outro com display:none — não removendo do DOM. Então,
      // dentro desses wrappers, um elemento "invisível" ainda é o link de
      // Like de verdade (só escondido pelo breakpoint atual), e clicar nele
      // via JS continua funcionando normalmente. Só filtramos por
      // visibilidade fora desse caso, pra não contar templates/lixo de DOM.
      const insideResponsiveToggle = !!anchor.closest('.desktop-only, .mobile-only');
      if (!insideResponsiveToggle) {
        const rect = anchor.getBoundingClientRect();
        const style = getComputedStyle(anchor);
        if (rect.width === 0 && rect.height === 0) return;
        if (style.display === 'none' || style.visibility === 'hidden') return;
      }

      const card = anchor.closest('div, li') || anchor.parentElement;
      cards.push({ anchor, card });
      const photoId = getPhotoId(anchor, card);
      if (photoId) seenPhotoIds.add(photoId);
    });

    // Botão de Like injetado pro layout mobile (ver injectMobileLikeButtons):
    // conta como âncora própria — é assim que "Curtir faltantes" e o
    // contador do widget passam a enxergar essas fotos também. Só pula se
    // já existir um link nativo detectado pra essa mesma foto acima (evita
    // duplicar caso a página tenha acabado de trocar de layout, ex. uma
    // janela sendo redimensionada em tempo real).
    document.querySelectorAll('.' + MOBILE_LIKE_BTN_CLASS).forEach(btn => {
      if (seenAnchors.has(btn)) return;
      const card = btn.closest('.result[data-photo]') || btn.parentElement;
      const photoId = getPhotoId(btn, card);
      if (photoId && seenPhotoIds.has(photoId)) return; // já coberto pelo link nativo
      seenAnchors.add(btn);
      cards.push({ anchor: btn, card });
    });

    return cards;
  }

  // =======================================================================
  // LIKE NO LAYOUT MOBILE — abaixo de um certo breakpoint de largura, o
  // JetPhotos esconde o link de Like inteiro (fica só a contagem em
  // estrela, sem ação nenhuma) via a classe ".desktop-only" citada acima.
  // O elemento continua no DOM, então em vez de reinventar a requisição a
  // gente injeta um botão visível em ".result__stats" que só REPASSA o
  // clique pro link nativo escondido — o content-hook.js confirma a
  // requisição exatamente como já fazia no desktop, sem sistema paralelo.
  // Só cai num fallback de requisição própria (performLikeRequest) se por
  // algum motivo o link nativo não existir de fato nesse card.
  // =======================================================================

  const MOBILE_LIKE_STAT_CLASS = 'jp-mobile-like-stat';
  const MOBILE_LIKE_BTN_CLASS = 'jp-mobile-like-btn';
  const MOBILE_LIKE_BTN_LIKED_CLASS = 'jp-mobile-like-btn--liked';
  const MOBILE_LIKE_ICON_URL = 'https://www.jetphotos.com/assets/img/thumbs-up-black.svg';

  // Confirma sucesso pelo TEXTO da resposta ("true"/"false" ou JSON), não só
  // pelo status HTTP — mesmo critério do content-hook.js (ver comentário lá
  // sobre por que o 200 sozinho não basta). Só é usado no fallback abaixo.
  function parseLikeSuccessText(bodyText, httpOk) {
    if (typeof bodyText === 'string' && bodyText.trim()) {
      const trimmed = bodyText.trim().toLowerCase();
      if (trimmed === 'true') return true;
      if (trimmed === 'false') return false;
      try {
        const json = JSON.parse(trimmed);
        if (typeof json === 'boolean') return json;
        if (json && typeof json.success === 'boolean') return json.success;
        if (json && typeof json.ok === 'boolean') return json.ok;
      } catch (_) { /* não é JSON, cai no fallback do status abaixo */ }
    }
    return httpOk;
  }

  // Fallback: só roda se o card não tiver NENHUM link nativo de Like (nem
  // escondido). Dispara a mesma requisição que o site faria.
  async function performLikeRequest(photoId, action) {
    const param = action === 'remove' ? 'removeFavorite' : 'addFavorite';
    const url = `${location.origin}/PostHandler.php?${param}=${encodeURIComponent(photoId)}&doAjax=true`;
    try {
      const res = await fetch(url, { method: 'GET', credentials: 'same-origin' });
      const text = await res.text().catch(() => '');
      return parseLikeSuccessText(text, res.ok);
    } catch (_) {
      return false; // falha de rede: não conta como curtida, igual ao fluxo desktop
    }
  }

  function applyMobileButtonState(button, liked) {
    button.classList.toggle(MOBILE_LIKE_BTN_LIKED_CLASS, liked);
    button.setAttribute('aria-pressed', liked ? 'true' : 'false');
    paintLikeIconGreen(button, liked);
  }

  const MOBILE_LIKE_BTN_POP_CLASS = 'jp-mobile-like-btn--pop';

  // Dispara o pop do joinha (ver CSS jpLikePop). Remove e readiciona a
  // classe com um reflow forçado no meio pra animação reiniciar mesmo se o
  // usuário curtir/descurtir/curtir rápido em sequência.
  function popMobileButton(button) {
    button.classList.remove(MOBILE_LIKE_BTN_POP_CLASS);
    void button.offsetWidth;
    button.classList.add(MOBILE_LIKE_BTN_POP_CLASS);
  }

  async function handleMobileLikeClick(button, photoId, nativeAnchor) {
    if (button.disabled) return; // evita duplo-toque disparar duas requisições
    button.disabled = true;
    button.classList.add('jp-mobile-like-btn--pending');

    // UI otimista: o joinha acende NA HORA do toque, sem esperar a resposta
    // do servidor (no celular essa confirmação demora e o botão parecia
    // "morto"). Se o servidor recusar, o evento de rede (!ok) desfaz tudo
    // em handleLikeNetResult — ver comentário lá.
    const willLike = !button.classList.contains(MOBILE_LIKE_BTN_LIKED_CLASS);
    applyMobileButtonState(button, willLike);
    if (willLike) popMobileButton(button);

    if (nativeAnchor) {
      // Aciona o link nativo do JetPhotos (existe no DOM, só escondido pelo
      // layout mobile). O content-hook.js confirma via rede e
      // handleLikeNetResult já cuida do cache + realce + contador — aqui só
      // reabilitamos o botão depois de uma janela curta anti-duplo-toque.
      nativeAnchor.click();
      setTimeout(() => {
        button.disabled = false;
        button.classList.remove('jp-mobile-like-btn--pending');
      }, 300);
      return;
    }

    // Sem link nativo disponível nesse card (não deveria acontecer no
    // layout atual do site, mas evita deixar o botão sem função caso o
    // JetPhotos mude a estrutura): usa o mesmo endpoint diretamente.
    const action = willLike ? 'add' : 'remove';
    const ok = await performLikeRequest(photoId, action);
    button.disabled = false;
    button.classList.remove('jp-mobile-like-btn--pending');
    if (!ok) {
      applyMobileButtonState(button, !willLike); // desfaz o otimismo
      return;
    }
    if (action === 'add') markPhotoLikedInCache(photoId); else unmarkPhotoLikedInCache(photoId);
    if (!isLiking) refresh(); // durante a leva em massa o refresh final cobre tudo
  }

  // Varre os cards e injeta o botão como último ".result__stat" só onde o
  // layout atual não mostra nenhum controle de Like visível. Idempotente:
  // já sai se o botão já existir ali, então pode rodar a cada refresh().
  function injectMobileLikeButtons() {
    document.querySelectorAll('.result[data-photo]').forEach(card => {
      if (card.classList.contains('result--adv')) return; // pula anúncios

      const nativeImg = card.querySelector('img[alt="Like"], img[title="Like"]');
      const nativeAnchor = nativeImg?.closest('a') || null;
      const nativeVisible = !!nativeAnchor && (() => {
        const rect = nativeAnchor.getBoundingClientRect();
        return !(rect.width === 0 && rect.height === 0) && getComputedStyle(nativeAnchor).display !== 'none';
      })();

      const existingStat = card.querySelector('.' + MOBILE_LIKE_STAT_CLASS);
      if (nativeVisible) {
        // A janela pode ter voltado pro layout desktop em tempo real
        // (redimensionamento) — se sobrou um botão nosso injetado antes,
        // remove, já que o like nativo visível cobre a foto sozinho agora.
        if (existingStat) existingStat.remove();
        return;
      }
      if (existingStat) return; // já injetado e ainda necessário nesse layout

      const statsRow = card.querySelector('.result__stats');
      if (!statsRow) return; // estrutura diferente do esperado: não sabemos onde encaixar, não injeta

      const photoId = card.dataset.photo;
      if (!photoId) return;

      const stat = document.createElement('div');
      stat.className = 'result__stat ' + MOBILE_LIKE_STAT_CLASS;

      const button = document.createElement('button');
      button.type = 'button';
      button.className = MOBILE_LIKE_BTN_CLASS;
      button.setAttribute('aria-label', t('likeWidgetLabel'));

      const icon = document.createElement('img');
      icon.src = MOBILE_LIKE_ICON_URL;
      icon.alt = 'Like';
      icon.className = 'mobile-only icon';
      button.appendChild(icon);
      stat.appendChild(button);
      statsRow.appendChild(stat);

      applyMobileButtonState(button, nativeAnchor ? isAlreadyLiked(nativeAnchor, card) : isPhotoLikedInCache(photoId));

      button.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();
        handleMobileLikeClick(button, photoId, nativeAnchor);
      });
      button.addEventListener('animationend', event => {
        if (event.animationName === 'jpLikePop') button.classList.remove(MOBILE_LIKE_BTN_POP_CLASS);
      });
    });
  }


  // ---------------------------------------------------------------------
  // UI: ícones simples em SVG inline (sem depender de assets externos)
  // ---------------------------------------------------------------------
  // stroke="currentColor" nesses 3 ícones neutros: assim eles herdam a cor
  // do elemento pai via CSS (var(--jp-icon-color)), o que permite recolori-los
  // automaticamente no dark mode sem precisar duplicar SVGs.
  const ICON_REFRESH = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="23 4 23 10 17 10"></polyline>
      <polyline points="1 20 1 14 7 14"></polyline>
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
    </svg>`;


  const ICON_CLOCK = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="10"></circle>
      <polyline points="12 6 12 12 16 14"></polyline>
    </svg>`;


  // ---------------------------------------------------------------------
  // Animações: tudo centralizado numa única <style>, rápido e simples.
  // Respeita prefers-reduced-motion pra usuários sensíveis a movimento.
  // ---------------------------------------------------------------------
  const STYLE_ID = 'jp-plus-styles';
  // Filtros SVG de cor exata (like curtido = mesmo tom do rótulo).
  // feColorMatrix constante: todo pixel opaco vira o verde alvo (o alfa
  // é preservado, então anti-serrilhado continua suave). Referência
  // same-document (url(#id)): sem fetch, sem problema de CSP/encoding.
  const LIKE_GREEN_SVG_ID = 'jp-like-green-filters';
  function ensureLikeGreenFilters() {
    if (document.getElementById(LIKE_GREEN_SVG_ID)) return;
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('id', LIKE_GREEN_SVG_ID);
    svg.setAttribute('width', '0');
    svg.setAttribute('height', '0');
    svg.setAttribute('aria-hidden', 'true');
    svg.style.position = 'absolute';
    svg.innerHTML = `
      <filter id="jp-green-dark"><feColorMatrix type="matrix" values="0 0 0 0 0.239 0 0 0 0 0.863 0 0 0 0 0.518 0 0 0 1 0"/></filter>
      <filter id="jp-green-light"><feColorMatrix type="matrix" values="0 0 0 0 0.094 0 0 0 0 0.502 0 0 0 0 0.220 0 0 0 1 0"/></filter>`;
    (document.head || document.documentElement).appendChild(svg);
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      /* JetPhotos site dark-mode overrides. These target only site elements
         whose original light-theme colors become unreadable on dark backgrounds.
         They are scoped to the extension's dark-mode class so normal JetPhotos
         colors remain completely untouched when dark mode is off. */
      /* Like curtido (TESTE): rótulo verde no modo escuro (#3ddc84). O
         ícone verde vai na regra do bloco abaixo; o tom do modo claro fica
         no estilo geral da extensão (fora do escopo dark). */
      html.jp-site-dark-active a.social__link.social__link--like.social__link--active,
      html.jp-site-dark-active a.social__link.social__link--like.social__link--active .social__text {
        color: #3ddc84 !important;
        -webkit-text-fill-color: #3ddc84 !important;
      }

      /* Account submenu: JetPhotos keeps these native account links at
         #282828 in the normal state and only turns them white on hover.
         With the extension site dark mode enabled, the submenu background is
         dark, so force all account submenu links to the same light text color
         in their normal state as well. The rule is scoped to dark mode and
         covers every item (Profile, Photos, Change password, Log out). */
      html.jp-site-dark-active .nav-desktop__list--username .nav-desktop__list--submenu .nav-desktop__link {
        color: #ffffff !important;
        -webkit-text-fill-color: #ffffff !important;
      }

      /* Photographer carousel arrows: JetPhotos has a more specific
         .slick-prev rule with a light #ececec gradient. Override both
         arrows only while extension dark mode is active, keeping the
         normal site appearance untouched outside dark mode. */
      html.jp-site-dark-active .slick-next {
        background: linear-gradient(86deg, hsl(0deg 0% 14.32% / 10%), #1c1b1b) !important;
      }

      html.jp-site-dark-active .slick-prev {
        background: linear-gradient(274deg, hsl(0deg 0% 14.32% / 10%), #1c1b1b) !important;
      }

      /* Hover branco (rótulos) só com mouse de verdade, pelo mesmo
         motivo acima (hover grudado no touch). */
      @media (hover:hover) and (pointer:fine) {
      /* Hover state: JetPhotos' original CSS changes .social__link to a
         dark color on hover. In dark mode that becomes unreadable, so keep
         every social action link light while hovered. This is intentionally
         separate from the active-state rule above. */
      html.jp-site-dark-active a.social__link:hover,
      html.jp-site-dark-active a.social__link:hover .social__text {
        color: #ffffff !important;
        -webkit-text-fill-color: #ffffff !important;
      }
      }

      /* Curtido + hover: continua verde (curtida = verde, sempre). */
      html.jp-site-dark-active a.social__link.social__link--like.social__link--active:hover,
      html.jp-site-dark-active a.social__link.social__link--like.social__link--active:hover .social__text {
        color: #3ddc84 !important;
        -webkit-text-fill-color: #3ddc84 !important;
      }

      /* Queue estimator: DOM próprio da extensão, com as cores dark-mode
         aqui mesmo (o tema manual do site não toca em nada com id jp-*). */
      html.jp-site-dark-active #jp-site-queue-tracker,
      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-queue-table,
      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-queue-table tbody {
        background: transparent !important;
        background-color: transparent !important;
      }

      /* O Period Totals original usa zebra striping: a segunda fileira
         recebe fundo elevado e a primeira permanece integrada ao fundo da página.
         O estimador replica exatamente esse comportamento no dark mode. */
      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-queue-table tbody tr:nth-child(even),
      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-queue-table tbody tr:nth-child(even) td {
        background: #2d2e31 !important;
        background-color: #2d2e31 !important;
        color: #e8eaed !important;
        border-color: #3c4043 !important;
      }

      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-queue-table tbody tr:nth-child(odd),
      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-queue-table tbody tr:nth-child(odd) td {
        background: transparent !important;
        background-color: transparent !important;
        color: #e8eaed !important;
        border-color: transparent !important;
      }

      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-queue-table td,
      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-metric {
        background: transparent !important;
        background-color: transparent !important;
        color: #e8eaed !important;
        border-color: #3c4043 !important;
      }

      /* Tabelas nativas do site marcadas via JS (Period Totals, fila):
         preserva o zebra striping com tons escuros. A segunda fileira fica
         levemente elevada; a primeira integra ao fundo da página. */
      html.jp-site-dark-active .jp-plus-dark-native-table tbody > tr:nth-child(even),
      html.jp-site-dark-active .jp-plus-dark-native-table tbody > tr:nth-child(even) td {
        background: #2d2e31 !important;
        background-color: #2d2e31 !important;
        color: #e8eaed !important;
        border-color: #3c4043 !important;
      }

      html.jp-site-dark-active .jp-plus-dark-native-table tbody > tr:nth-child(odd),
      html.jp-site-dark-active .jp-plus-dark-native-table tbody > tr:nth-child(odd) td {
        background: transparent !important;
        background-color: transparent !important;
        color: #e8eaed !important;
        border-color: transparent !important;
      }

      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-queue-table caption,
      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-metric strong {
        color: #e8eaed !important;
      }

      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-metric span {
        color: rgb(224 224 224) !important;
      }

      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-queue-note {
        color: #9aa0a6 !important;
      }

      html.jp-site-dark-active #jp-site-queue-tracker .jp-plus-experimental {
        color: #9aa0a6 !important;
      }

      html.jp-site-dark-active #jp-site-queue-tracker button {
        color: #9aa0a6 !important;
        background: transparent !important;
      }

      /* JetPhotos+ UI: intentionally follows the visual language of JetPhotos
         instead of looking like a separate Material-style application. */
      #jp-plus-launcher-host {
        position: relative;
        display: inline-flex;
        align-items: stretch;
        vertical-align: middle;
        z-index: 1000000;
        flex: 0 0 auto;
        list-style: none;
        margin: 0 0 0 18px !important;
        padding: 0;
      }
      #jp-plus-launcher {
        appearance: none;
        -webkit-appearance: none;
        box-sizing: border-box;
        min-width: 0;
        width: 42px;
        margin: 0;
        border: 0;
        background: transparent;
        color: inherit;
        font: inherit;
        line-height: inherit;
        letter-spacing: inherit;
        text-align: center;
        white-space: nowrap;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding-left: 8px;
        padding-right: 8px;
      }
      #jp-plus-launcher .jp-launcher-logo {
        display: block;
        width: 27px;
        height: 29px;
        object-fit: contain;
        flex: 0 0 auto;
        filter: brightness(0) invert(1);
        transition: filter .18s ease, transform .18s ease;
      }
      /* O PNG original é preto/transparente. No header ele fica branco e,
         ao passar o mouse ou receber foco, muda suavemente para o azul da
         identidade da extensão. */
      #jp-plus-launcher-host:hover > #jp-plus-launcher .jp-launcher-logo,
      #jp-plus-launcher-host:focus-within > #jp-plus-launcher .jp-launcher-logo {
        filter: brightness(0) saturate(100%) invert(51%) sepia(98%) saturate(2437%) hue-rotate(190deg) brightness(101%) contrast(102%);
        transform: scale(1.04);
      }
      /* Submenu próprio da extensão: mesma linguagem dos dropdowns nativos. */
      #jp-plus-submenu {
        position: absolute !important;
        top: 100% !important;
        left: calc(50% + 8px) !important;
        right: auto !important;
        transform: translateX(-50%);
        width: 170px !important;
        box-sizing: border-box;
        display: none;
        margin: 0 !important;
        padding: 0 !important;
        background: #ffffff;
        color: #222222;
        border: 0;
        border-radius: 0 !important;
        box-shadow: 0 2px 7px rgba(0,0,0,.22);
        overflow: hidden;
        z-index: 1000001;
        font-family: inherit !important;
      }
      #jp-plus-launcher-host:hover > #jp-plus-submenu,
      #jp-plus-launcher-host:focus-within > #jp-plus-submenu {
        display: block !important;
      }
      #jp-plus-submenu a {
        display: block;
        box-sizing: border-box;
        width: 100%;
        padding: 10px 13px;
        color: #222222;
        border: 0 !important;
        outline: none !important;
        box-shadow: none;
        background: #ffffff;
        text-decoration: none;
        font: inherit;
        font-size: 14px;
        line-height: 1.3;
        white-space: nowrap;
      }
      #jp-plus-submenu a:hover,
      #jp-plus-submenu a:focus-visible {
        background: #4299dc;
        color: #ffffff;
        outline: none !important;
        border: 0 !important;
        box-shadow: none;
      }
      #jp-plus-submenu.jp-dark {
        background: #292929;
        color: #eeeeee;
      }
      #jp-plus-submenu.jp-dark a {
        background: #292929;
        color: #eeeeee;
      }
      #jp-plus-submenu.jp-dark a:hover,
      #jp-plus-submenu.jp-dark a:focus-visible {
        background: #3d91d1;
        color: #ffffff;
        border: 0 !important;
        outline: none !important;
      }

      /* Host mobile (FAB): visível só quando o launcher do header não
         está renderizado (layout mobile). Disco branco com a logo preta,
         no canto oposto ao da bolha de likes. */
      #jp-plus-mobile-host { position:fixed; left:16px; bottom:16px; z-index:999999; }
      #jp-plus-mobile-fab {
        display:flex; align-items:center; justify-content:center;
        width:52px; height:52px; border-radius:50%;
        background:#ffffff; border:1px solid rgba(0,0,0,.12);
        box-shadow:0 5px 20px rgba(0,0,0,.30);
        cursor:pointer; padding:0;
        -webkit-tap-highlight-color:transparent;
        transition:transform .06s ease-out, background .12s ease;
      }
      #jp-plus-mobile-fab img { display:block; width:30px; height:32px; object-fit:contain; }
      @media (hover:hover) {
        #jp-plus-mobile-fab:hover { background:#f0f0f0; }
      }
      #jp-plus-mobile-fab:active { transform:scale(.92); }
      #jp-plus-mobile-fab:focus-visible { outline:2px solid #2c94e8; outline-offset:2px; }
      #jp-plus-mobile-host.jp-dark #jp-plus-mobile-fab { background:#1c1c1c; border-color:#464646; }
      #jp-plus-mobile-host.jp-dark #jp-plus-mobile-fab img { filter:brightness(0) invert(1); }
      /* Docagem do FAB: parado, meio escondido na lateral esquerda + translúcido. A classe
         jp-fab-docked vai no host, mas o efeito vai no invólucro — o submenu e
         o painel moram no mesmo host e não podem ser arrastados juntos. */
      #jp-plus-mobile-fab-wrap { display:block; width:52px; height:52px; transition:transform .22s ease, opacity .22s ease; }
      #jp-plus-mobile-host.jp-fab-docked #jp-plus-mobile-fab-wrap { transform:translateX(calc(-50% - 16px)); opacity:.5; }
      @media (prefers-reduced-motion: reduce) {
        #jp-plus-mobile-fab-wrap { transition:none; }
      }
      /* Submenu mobile: os mesmos 4 itens do PC, em folha acima do FAB. */
      #jp-plus-mobile-host > #jp-plus-mobile-submenu {
        display:none;
        position:absolute; left:0; bottom:62px;
        width:230px; box-sizing:border-box;
        background:#ffffff; color:#222222;
        border:1px solid rgba(0,0,0,.12); border-radius:12px;
        box-shadow:0 8px 28px rgba(0,0,0,.32);
        overflow:hidden; padding:6px;
        font-family:inherit;
      }
      #jp-plus-mobile-host.jp-mobile-menu-open > #jp-plus-mobile-submenu { display:block; animation:jpMobileMenuIn .11s ease; }
      @keyframes jpMobileMenuIn { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:none; } }
      @media (prefers-reduced-motion: reduce) {
        #jp-plus-mobile-host.jp-mobile-menu-open > #jp-plus-mobile-submenu { animation:none; }
      }
      #jp-plus-mobile-host.jp-settings-open > #jp-plus-mobile-submenu { display:none !important; }
      #jp-plus-mobile-submenu a {
        display:block; padding:11px 12px; border-radius:8px;
        color:#222222; background:transparent; text-decoration:none;
        font-size:15px; line-height:1.3;
      }
      #jp-plus-mobile-submenu a:active { background:#e8e8e8; }
      #jp-plus-mobile-host > #jp-plus-mobile-submenu.jp-dark { background:#292929; color:#eeeeee; }
      #jp-plus-mobile-submenu.jp-dark a { color:#eeeeee; }
      #jp-plus-mobile-submenu.jp-dark a:active { background:#3d3d3d; }
      /* Painel de configs no host mobile: folha sobre o FAB. */
      #jp-plus-mobile-host > #jp-plus-settings-panel {
        position:absolute !important; left:0 !important; bottom:62px !important;
        top:auto !important; right:auto !important;
        width:min(330px, calc(100vw - 32px)) !important;
        transform:translateY(8px);
        border-radius:16px;
      }
      #jp-plus-mobile-host.jp-settings-open > #jp-plus-settings-panel { display:block !important; }
      #jp-plus-mobile-host.jp-settings-open #jp-plus-settings-panel { opacity:1; transform:none; }
      /* Backdrop invisível: garante o fechar-ao-clicar-fora (PC e mobile). */
      #jp-plus-backdrop {
        display:none;
        position:fixed; inset:0; z-index:999998;
        background:rgba(0,0,0,0); border:0; padding:0; margin:0;
      }
      #jp-plus-backdrop.jp-backdrop-show { display:block; }

      /* Bolha de curtidas: o único UI de likes — aparece somente em páginas
         que realmente possuem links/ícones de Like. Não é launcher.
         Sempre visível; compacta — coração + faltantes. */
      #jp-like-widget-bubble {
        position:fixed; right:18px; bottom:18px; z-index:999999;
        display:flex; align-items:center; gap:9px;
        min-height:54px; padding:12px 18px 12px 16px; box-sizing:border-box;
        background:#1c1c1c; color:#eeeeee;
        border:1px solid #464646; border-radius:999px;
        box-shadow:0 5px 20px rgba(0,0,0,.30);
        font-family:'Fira Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size:15px; font-weight:700; line-height:1;
        cursor:pointer;
        animation:jpBubbleIn .18s ease;
      }
      #jp-like-widget-bubble:hover { background:#2a2a2a; border-color:#686868; }
      #jp-like-widget-bubble:focus-visible { outline:2px solid #669DF6; outline-offset:2px; }
      /* Concluído: a bolha encolhe pra um disco só com o selo — o contador
         some junto (sem "0" pendurado do lado). Padding igual dos 4 lados
         centraliza o selo; vale em qualquer breakpoint (seletor mais
         específico que os paddings dos @media). */
      #jp-like-widget-bubble.jp-bubble-done { padding:12px; gap:0; min-height:0; }
      #jp-like-widget-bubble.jp-bubble-done #jp-like-widget-bubble-count { display:none; }
      /* Durante a leva, a bolha só troca a borda pra verde (estado estático,
         sem pulsar — o progresso aparece no anel e na contagem regressiva). */
      #jp-like-widget-bubble.jp-bubble-liking { border-color:#4caf50; }
      /* Anel de progresso em volta do coração: o track fica sempre visível
         (contorno sutil) e o fill verde fecha conforme a leva avança (ver
         setBubbleProgress). Começa no topo por causa do rotate(-90deg). */
      /* O coração é centralizado por flex (à prova de conta de margem) e o
         anel preenche o wrap em absoluto — assim os dois ficam concêntricos
         de verdade, sem depender de margin:auto + inset. */
      #jp-like-widget-bubble .jp-bubble-ring-wrap { position:relative; width:32px; height:32px; flex:0 0 auto; display:flex; align-items:center; justify-content:center; }
      #jp-like-widget-bubble .jp-bubble-ring { position:absolute; inset:0; width:100%; height:100%; transform:rotate(-90deg); }
      #jp-like-widget-bubble .jp-bubble-ring-track { fill:none; stroke:rgba(255,255,255,.16); stroke-width:2.5; }
      #jp-like-widget-bubble .jp-bubble-ring-fill { fill:none; stroke:#4caf50; stroke-width:2.5; stroke-linecap:round; stroke-dasharray:75.4; stroke-dashoffset:75.4; transition:stroke-dashoffset .15s linear, opacity .15s linear; }
      #jp-like-widget-bubble .jp-bubble-thumb { position:relative; width:19px; height:19px; }
      /* Selo de concluído: quando tudo está curtido, o anel + joinha dão
         lugar a um disco verde com confere branco (troca seca, sem pop). */
      #jp-like-widget-bubble .jp-bubble-check { display:none; position:absolute; inset:0; width:100%; height:100%; padding:0; box-sizing:border-box; }
      #jp-like-widget-bubble .jp-bubble-check { display:flex; align-items:center; justify-content:center; }
      #jp-like-widget-bubble .jp-bubble-check svg { display:block; width:100%; height:100%; padding:4px 3px 4px 5px; box-sizing:border-box; }77240749094899d59975508229e0aca1f
      #jp-like-widget-bubble.jp-bubble-done .jp-bubble-ring,
      #jp-like-widget-bubble.jp-bubble-done .jp-bubble-thumb { display:none; }
      #jp-like-widget-bubble.jp-bubble-done .jp-bubble-check { display:flex; }
      /* Rótulo só no desktop largo (ex: "10 faltando"): deixa a bolha mais
         larga e autoexplicativa onde há espaço; some no mobile. */
      #jp-like-widget-bubble .jp-bubble-label { display:none; font-weight:600; opacity:.75; }
      /* A bolha cresce com a tela: compacta no celular, com presença no PC.
         O anel é viewBox e escala sozinho junto com o wrap. */
      @media (min-width:700px) {
        #jp-like-widget-bubble { min-height:58px; padding:13px 20px 13px 17px; font-size:16px; }
        #jp-like-widget-bubble .jp-bubble-ring-wrap { width:34px; height:34px; }
        #jp-like-widget-bubble .jp-bubble-thumb { width:21px; height:21px; }
      }
      @media (min-width:1100px) {
        #jp-like-widget-bubble { min-height:62px; padding:14px 22px 14px 18px; font-size:16px; gap:10px; }
        #jp-like-widget-bubble .jp-bubble-ring-wrap { width:36px; height:36px; }
        #jp-like-widget-bubble .jp-bubble-thumb { width:21px; height:21px; }
        #jp-like-widget-bubble .jp-bubble-label { display:inline; }
      }
      @media (prefers-reduced-motion: reduce) {
        #jp-like-widget-bubble { animation:none; }
        #jp-like-widget-bubble .jp-bubble-ring-fill { transition:none; }
        #jp-like-toast { transition:none; }
      }
      @keyframes jpBubbleIn { from {opacity:0} to {opacity:1} }
      /* Toast de aviso da bolha com a cara do site: cartão claro como os
         cards de resultado, texto escuro e filete azul como os botões. A fonte
         é declarada explícita (pilha sans do sistema, igual à do site) em vez
         de herdada — herança falha se o site escopar a fonte em wrappers. */
      #jp-like-toast {
        position:fixed; left:50%; bottom:28px; transform:translateX(-50%); z-index:1000000;
        max-width:min(420px, calc(100vw - 32px)); box-sizing:border-box;
        background:#ffffff; color:#212121;
        border:1px solid #d8d8d8; border-left:4px solid #1f8dd6; border-radius:8px;
        padding:11px 16px;
        font-family:'Fira Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        font-size:14px; font-weight:600; line-height:1.35; text-align:center;
        box-shadow:0 5px 20px rgba(0,0,0,.22); pointer-events:none;
        opacity:0; transition:opacity .18s ease;
      }
      #jp-like-toast.jp-toast-show { opacity:1; }

      #jp-like-settings-menu {
        position: absolute !important;
        top: 100% !important;
        right: 0 !important;
        width: 360px !important;
        max-width: min(360px, calc(100vw - 18px));
        box-sizing: border-box;
        display: none;
        margin: 0 !important;
        padding: 0 14px 14px !important;
        background: #ffffff;
        color: #222222;
        border: 1px solid #c8c8c8;
        border-top: 0;
        border-radius: 0 !important;
        box-shadow: 0 2px 8px rgba(0,0,0,.24);
        z-index: 1000002;
        opacity: 0;
        transform: translateY(-5px);
        transition: opacity .16s ease, transform .16s ease;
        font-family: inherit !important;
      }
      #jp-plus-launcher-host.jp-settings-open > #jp-plus-settings-panel { display: block !important; }
      #jp-plus-launcher-host.jp-settings-open > #jp-plus-submenu { display: none !important; }
      #jp-plus-settings-panel {
        --jp-bg: #ffffff;
        --jp-text: #222222;
        --jp-subtext: #666666;
        --jp-border: #c8c8c8;
        --jp-toggle-off: #bdbdbd;
        position: absolute !important;
        top: 100% !important;
        right: 0 !important;
        width: 360px !important;
        max-width: min(360px, calc(100vw - 18px));
        box-sizing: border-box;
        display: none;
        background: #ffffff;
        color: #222222;
        border: 1px solid #c8c8c8;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 12px 32px rgba(0,0,0,.28);
        z-index: 1000002;
        opacity: 0;
        transform: translateY(-5px);
        transition: opacity .16s ease, transform .16s ease;
        font-family: inherit !important;
      }
      /* O painel vive dentro do mesmo <li> do menu de conta do JetPhotos,
         e o menu nativo do site força white-space:nowrap nos próprios itens
         (comum em nav horizontal) — como white-space é herdado, os nossos
         textos de ajuda puxavam esse nowrap do site, viravam uma linha só
         enorme, e o overflow-x:hidden do painel cortava tudo no meio, sem
         quebra nem reticências. Resetando aqui, com !important, isolamos
         o conteúdo do painel do CSS do site, então o texto sempre quebra
         linha normalmente dentro da largura de 360px. */
      #jp-plus-settings-panel, #jp-plus-settings-panel * {
        white-space: normal !important;
      }
      #jp-plus-settings-panel.jp-dark {
        --jp-bg: #292929;
        --jp-text: #eeeeee;
        --jp-subtext: #b6b6b6;
        --jp-border: #505050;
        --jp-toggle-off: #555555;
        background:#292929; color:#eeeeee; border-color:#505050;
      }
      #jp-plus-settings-panel #jp-like-settings-menu {
        display:block !important;
        opacity:1 !important;
        transform:none !important;
        position:static !important;
        width:auto !important;
        max-width:none !important;
        margin:0 !important;
        padding:0 0 2px !important;
        background:transparent !important;
        border:0 !important;
        box-shadow:none !important;
      }
      #jp-plus-settings-panel .jp-settings-title {
        display:flex; align-items:center; justify-content:space-between; gap:10px;
        padding:12px 12px 12px 16px;
        background:#2c94e8;
        color:#ffffff;
        font-size:15px;
        font-weight:700;
        line-height:1.2;
      }
      #jp-plus-settings-panel .jp-settings-body {
        max-height: min(70vh, 520px);
        overflow-y: auto;
        overflow-x: hidden;
        padding: 0 16px 16px;
        box-sizing: border-box;
      }
      #jp-plus-settings-panel .jp-settings-body #jp-like-settings-menu {
        width: 100% !important;
        max-width: 100% !important;
        box-sizing: border-box;
        overflow-x: hidden;
      }
      #jp-plus-settings-panel .jp-settings-body #jp-like-settings-menu > div {
        width: 100%;
        max-width: 100%;
        min-width: 0;
        box-sizing: border-box;
      }
      #jp-plus-settings-panel .jp-settings-body #jp-like-settings-menu > div > div {
        min-width: 0;
        max-width: 100%;
        box-sizing: border-box;
      }
      #jp-plus-settings-panel .jp-settings-body #jp-like-settings-menu span {
        overflow-wrap: anywhere;
        word-break: normal;
      }
      #jp-plus-settings-panel .jp-settings-body #jp-language-select {
        flex: 0 1 140px;
        width: 140px;
        max-width: 140px;
        min-width: 0;
        box-sizing: border-box;
      }
      #jp-plus-settings-panel .jp-settings-close {
        flex:0 0 auto;
        width:30px; height:30px; border-radius:50%;
        border:0; background:rgba(255,255,255,.20); color:#ffffff; cursor:pointer;
        font-size:18px; font-weight:400; line-height:1;
        display:flex; align-items:center; justify-content:center;
        padding:0 0 2px;
      }
      #jp-plus-settings-panel .jp-settings-close:hover { background:rgba(255,255,255,.35); }

      #jp-plus-settings-panel select { border-radius:8px !important; }
      #jp-plus-launcher-host.jp-settings-open #jp-plus-settings-panel {
        opacity: 1;
        transform: translateY(0);
      }

      @media (max-width: 520px) {
        #jp-plus-launcher { width: 38px !important; padding-left: 6px !important; padding-right: 6px !important; }
        #jp-plus-launcher .jp-launcher-logo { width: 25px; height: 27px; }
        #jp-plus-submenu { width: 170px !important; }
        #jp-plus-settings-panel { width: min(360px, calc(100vw - 18px)) !important; }
        #jp-like-widget-bubble { right:10px; bottom:10px; }
      }

      @media (prefers-reduced-motion: reduce) {
        #jp-like-widget-bubble { animation-duration:.001ms !important; transition-duration:.001ms !important; }
        #jp-plus-settings-panel { transition-duration:.001ms !important; }
        #jp-plus-launcher .jp-launcher-logo {
          transition-duration: .001ms !important;
        }
      }

      /* Botão de Like injetado como último ".result__stat" no layout
         mobile do JetPhotos (ver injectMobileLikeButtons). Usa o mesmo
         ícone .svg do site; a diferença entre curtida/não-curtida é só
         opacidade (o arquivo é preto fixo nos dois estados, então isso é
         suficiente e funciona igual em qualquer tema, sem depender do
         filtro de dark mode automático — por isso o tema manual do site
         nunca toca nesses ícones (ver a lista "nunca tocados" no tema).
         Alinhamento: o <img> é display:block pra eliminar a folga de
         baseline do inline (que deixava o ícone uns px acima dos vizinhos)
         e o stat usa inline-flex + vertical-align:middle pra acompanhar a
         altura dos outros ".result__stat" da fileira. A caixa do botão
         cresceu junto com o ícone (30px) mas a margem negativa compensa na
         mesma medida, então a altura da fileira continua igual à original.
         A margem vertical é assimétrica de propósito (-9px em cima, -5px
         embaixo): sobe o botão 2px em relação aos ícones vizinhos sem
         alterar a altura total ocupada (30 - 9 - 5 = 16px, igual antes). */
      .${MOBILE_LIKE_STAT_CLASS} { cursor:pointer; display:inline-flex; align-items:center; vertical-align:middle; }
      .${MOBILE_LIKE_BTN_CLASS} {
        display:inline-flex; align-items:center; justify-content:center;
        width:30px; height:30px; margin:-11px -4px -3px; padding:0;
        border:0; background:transparent; border-radius:50%;
        cursor:pointer; transition:background .15s ease, opacity .15s ease, transform .1s ease;
      }
      .${MOBILE_LIKE_BTN_CLASS} img { width:20px; height:20px; display:block; opacity:.4; pointer-events:none; }
      .${MOBILE_LIKE_BTN_CLASS}.${MOBILE_LIKE_BTN_LIKED_CLASS} img { opacity:1; }
      .${MOBILE_LIKE_BTN_CLASS}:active { transform:scale(.9); }
      .${MOBILE_LIKE_BTN_CLASS}:hover { background:rgba(0,0,0,.06); }
      /* Sem dim no pending: o clique já aplica o estado na hora (UI otimista)
         e o pop abaixo é o feedback — escurecer o botão brigaria com isso. */
      .${MOBILE_LIKE_BTN_CLASS}.jp-mobile-like-btn--pending { pointer-events:none; }
      /* Pop do joinha ao curtir: resposta instantânea e com um pouco de vida.
         Mora numa classe transitória (--pop), não no estado --liked, pra não
         repetir a cada refresh() — ver popMobileButton(). */
      @keyframes jpLikePop {
        0% { transform:scale(1); }
        40% { transform:scale(1.35); }
        70% { transform:scale(.95); }
        100% { transform:scale(1); }
      }
      .${MOBILE_LIKE_BTN_CLASS}.jp-mobile-like-btn--pop img { animation:jpLikePop .2s ease; }
      @media (prefers-reduced-motion: reduce) {
        .${MOBILE_LIKE_BTN_CLASS}.jp-mobile-like-btn--pop img { animation:none; }
      }
      /* Like curtido = verde (TESTE): vale nos dois temas — o bloco do
         modo escuro sobrescreve o tom quando ligado. Não-curtido segue o
         padrão de cada tema (claro: nativo do site; escuro: cinza claro). */
      a.social__link.social__link--like.social__link--active,
      a.social__link.social__link--like.social__link--active .social__text { color:#188038 !important; -webkit-text-fill-color:#188038 !important; }
      a.social__link.social__link--like.social__link--active :not(.social__text):not(:has(.social__text)),
      a.social__link.social__link--like.social__link--active::before,
      a.social__link.social__link--like.social__link--active::after,
      a.social__link.social__link--like.social__link--active .social__text::before,
      a.social__link.social__link--like.social__link--active .social__text::after { filter:url(#jp-green-light) !important; opacity:1 !important; }
      .jp-mobile-like-btn.jp-mobile-like-btn--liked img { filter:url(#jp-green-light) !important; }
    `;
    document.head.appendChild(style);
    ensureLikeGreenFilters();
  }

  // ---------------------------------------------------------------------
  // Preferências (chrome.storage.local)
  // ---------------------------------------------------------------------
  // Define o idioma inicial a partir do idioma preferido do navegador.
  // Português (incluindo pt-PT/pt-XX) usa a tradução pt-BR; inglês usa
  // English. Qualquer outro idioma cai para English, que é o fallback
  // universal da extensão. Se o usuário já escolheu manualmente um idioma,
  // a preferência salva em chrome.storage.local continua tendo prioridade.
  function getBrowserLanguage() {
    try {
      const languages = Array.isArray(navigator.languages) && navigator.languages.length
        ? navigator.languages
        : [navigator.language || ''];
      for (const raw of languages) {
        const lang = String(raw).toLowerCase();
        if (lang === 'pt' || lang.startsWith('pt-')) return 'pt-BR';
        if (lang === 'en' || lang.startsWith('en-')) return 'en';
      }
    } catch (_) {}
    return 'en';
  }

  function getSettings() {
    return new Promise(resolve => {
      getExtensionStorage(
        [STORAGE_KEY_SITE_DARK_MODE, STORAGE_KEY_QUEUE_ESTIMATOR_ENABLED, STORAGE_KEY_LANGUAGE]
      ).then(result => {
        resolve({
          siteDarkMode: result[STORAGE_KEY_SITE_DARK_MODE] === true, // padrão: false
          queueEstimatorEnabled: result[STORAGE_KEY_QUEUE_ESTIMATOR_ENABLED] !== false, // padrão: true (EXPERIMENTAL)
          language: result[STORAGE_KEY_LANGUAGE] || getBrowserLanguage()
        });
      });
    });
  }


  function setSiteDarkMode(value) {
    setExtensionStorage({ [STORAGE_KEY_SITE_DARK_MODE]: value });
  }

  function setQueueEstimatorEnabled(value) {
    setExtensionStorage({ [STORAGE_KEY_QUEUE_ESTIMATOR_ENABLED]: value });
  }

  function setLanguage(value) {
    setExtensionStorage({ [STORAGE_KEY_LANGUAGE]: value });
  }

  // =======================================================================
  // -----------------------------------------------------------------------
  // Modo escuro do SITE (não só do painel). TEMA MANUAL: folha de estilo
  // escrita à mão para os seletores reais do JetPhotos (paleta + classes
  // BEM extraídas do site via snippet de console).
  //
  // Por que manual, depois de duas tentativas automáticas:
  //   - "smart invert" (filter global + reinversão): quebrava o matiz de
  //     cores saturadas e errava fotos de lazy-load.
  //   - recoloração por elemento (getComputedStyle + !important inline +
  //     observer): piscava em conteúdo dinâmico, errava gradientes, bordas,
  //     sombras e iframes, e custava CPU revisitando o DOM inteiro.
  // O tema manual não tem JS de varredura: é só uma classe no <html>
  // (jp-site-dark-active) + CSS com !important. Fotos, vídeos, canvas, SVG,
  // iframes, o header (já escuro) e cores de marca (azul picton, botões de
  // share) nunca são tocados — as regras miram só página, cards, textos,
  // links, formulários e controles.
  // -----------------------------------------------------------------------
  const SITE_DARK_HTML_CLASS = 'jp-site-dark-active';
  const SITE_DARK_STYLE_ID = 'jp-site-dark-theme';

  const SITE_DARK_THEME_CSS = `
    html.jp-site-dark-active { color-scheme:dark; }
    /* Página: fundo + texto base (o #202124 casa com o preload anti-flash). */
    html.jp-site-dark-active body,
    html.jp-site-dark-active .page,
    html.jp-site-dark-active div[class*="page--"],
    html.jp-site-dark-active .main,
    html.jp-site-dark-active .main__section { background-color:#202124 !important; color:#e8e8e8 !important; }
    /* Cards brancos (resultados, painéis). */
    html.jp-site-dark-active .box,
    html.jp-site-dark-active div[class*="box--"] { background-color:#2b2d31 !important; color:#e8e8e8 !important; border-color:#3a3d43 !important; }
    /* Títulos. */
    html.jp-site-dark-active h1,
    html.jp-site-dark-active h2,
    html.jp-site-dark-active h3,
    html.jp-site-dark-active h4,
    html.jp-site-dark-active h5,
    html.jp-site-dark-active h6,
    html.jp-site-dark-active .head { color:#f2f2f2 !important; }
    /* Links: azul clareado pra leitura no escuro (o azul puro #2c94e8 e o
       azul-link padrão #0000ee somem no fundo escuro). Botões, logo e moldura
       de foto ficam de fora — têm estilo próprio. */
    html.jp-site-dark-active a:not(.btn):not(.header__logo):not(.gallery-photo__frame) { color:#6fb1f0 !important; }
    /* Guarda: o tema nunca toca nos links dos submenus da extensão. */
    html.jp-site-dark-active #jp-plus-submenu a,
    html.jp-site-dark-active #jp-plus-mobile-submenu a { color:inherit !important; }
    /* Links sobre fundos que já eram escuros (header, popups, dropdowns):
       herdam o branco do contexto em vez de forçar o azul. */
    html.jp-site-dark-active .header a:not(.btn):not(.header__logo):not(.gallery-photo__frame),
    html.jp-site-dark-active .gallery-photo__popup a:not(.btn):not(.header__logo):not(.gallery-photo__frame),
    html.jp-site-dark-active #quicksearch-dropdown a:not(.btn):not(.header__logo):not(.gallery-photo__frame),
    html.jp-site-dark-active #overlay a:not(.btn):not(.header__logo):not(.gallery-photo__frame),
    html.jp-site-dark-active .loader__mobile a:not(.btn):not(.header__logo):not(.gallery-photo__frame) { color:inherit !important; }
    /* Submenu desktop (era #fefefe). */
    html.jp-site-dark-active ul.nav-desktop__list--submenu { background-color:#2b2d31 !important; border-color:#3a3d43 !important; }
    /* Textos da galeria + rótulos de formulário. */
    html.jp-site-dark-active .gallery-photo__info,
    html.jp-site-dark-active .gallery-photo__text { color:#e8e8e8 !important; }
    html.jp-site-dark-active label.form__label { color:#b0b0b0 !important; }
    /* Campos: wrappers brancos + os inputs. */
    html.jp-site-dark-active .input-wrapper,
    html.jp-site-dark-active #header__searchBoxInputWrapper { background-color:#2b2d31 !important; border-color:#4b4e55 !important; }
    html.jp-site-dark-active input[type="text"],
    html.jp-site-dark-active input[type="search"],
    html.jp-site-dark-active input[type="email"],
    html.jp-site-dark-active input[type="password"],
    html.jp-site-dark-active input[type="url"],
    html.jp-site-dark-active input[type="number"],
    html.jp-site-dark-active input[type="tel"],
    html.jp-site-dark-active .input-wrapper__field,
    html.jp-site-dark-active .header__searchBoxInput,
    html.jp-site-dark-active textarea { background-color:#2b2d31 !important; color:#e8e8e8 !important; border-color:#4b4e55 !important; }
    html.jp-site-dark-active input::placeholder,
    html.jp-site-dark-active textarea::placeholder { color:#8e8e8e !important; opacity:1 !important; }
    /* Selects (busca avançada etc.) + as opções. */
    html.jp-site-dark-active select,
    html.jp-site-dark-active .select__control { background-color:#2b2d31 !important; color:#e8e8e8 !important; border-color:#4b4e55 !important; }
    html.jp-site-dark-active option,
    html.jp-site-dark-active optgroup { background-color:#2b2d31 !important; color:#e8e8e8 !important; }
    /* Botões genéricos claros viram escuros; o azul picton e o transparente
       ficam intactos (já funcionam no escuro). */
    html.jp-site-dark-active .btn:not(.btn--picton-blue):not(.btn--transparent) { background-color:#3a3d43 !important; color:#e8e8e8 !important; border-color:#4b4e55 !important; }
    /* Shares mantêm a cor de marca; só garante o texto branco. */
    html.jp-site-dark-active .resp-sharing-button a { color:#ffffff !important; }
    /* Setas do carrossel: gradiente claro -> escuro (mesma direção). */
    html.jp-site-dark-active .slick-prev { background-image:linear-gradient(90deg, #202124 0px, rgba(32,33,36,0)) !important; }
    html.jp-site-dark-active .slick-next { background-image:linear-gradient(90deg, rgba(32,33,36,0), #202124) !important; }
    /* Alertas: info azul + erro de login. */
    html.jp-site-dark-active #alert-email-verification { background-color:#16324a !important; color:#a8d4f5 !important; border-color:#1e659f !important; }
    html.jp-site-dark-active .alert__content { color:#a8d4f5 !important; }
    html.jp-site-dark-active #login-form__failed-login { background-color:#3d2223 !important; color:#f2b8b5 !important; }
    /* Modal de login. */
    html.jp-site-dark-active .modal { background-color:#2b2d31 !important; color:#e8e8e8 !important; border-color:#3a3d43 !important; }
    /* Rodapé. */
    html.jp-site-dark-active footer { background-color:#17181c !important; color:#cfcfcf !important; }
    html.jp-site-dark-active .footer__seperator { background-color:#3a3d43 !important; }
    /* Aba ativa do seletor + painéis de busca avançada. */
    html.jp-site-dark-active .bigbox-selector__tab--active { background-color:#2b2d31 !important; color:#e8e8e8 !important; }
    html.jp-site-dark-active .form--searchAdvanced,
    html.jp-site-dark-active .form--searchAdvancedMulti { background-color:#26272b !important; color:#e8e8e8 !important; }
    /* Tabelas genéricas: só a borda (fundo transparente mostra a página). */
    html.jp-site-dark-active table,
    html.jp-site-dark-active th,
    html.jp-site-dark-active td { border-color:#3a3d43 !important; }
    html.jp-site-dark-active th { color:#f2f2f2 !important; }
    html.jp-site-dark-active hr { border-color:#3a3d43 !important; background-color:#3a3d43 !important; }
    /* Home: coluna lateral + cards do carrossel de perfis. */
    html.jp-site-dark-active .index-col { background-color:#26272b !important; color:#e8e8e8 !important; border-color:#3a3d43 !important; }
    html.jp-site-dark-active .slick-profile__layout { background-color:#2b2d31 !important; color:#e8e8e8 !important; }
    html.jp-site-dark-active .slick-profile__layout span { color:#e8e8e8 !important; }
    /* Perfil: nome sobre a foto de capa fica branco (o "a" no seletor
       empata a especificidade com a regra genérica de links e vence por vir
       depois — sem ele, o nome continuaria azul). */
    html.jp-site-dark-active a.hero__profile-name-link { color:#ffffff !important; -webkit-text-fill-color:#ffffff !important; }
    /* Área de membros: painel das abas + botões das abas (mesmo motivo do
       "a" acima nas cores; fundo/borda não competem com regra genérica). */
    html.jp-site-dark-active .tabnav__content { background-color:#2b2d31 !important; color:#e8e8e8 !important; border-color:#3a3d43 !important; }
    html.jp-site-dark-active .tabnav__btn { background-color:#2b2d31 !important; border-color:#3a3d43 !important; }
    html.jp-site-dark-active a.tabnav__btn { color:#e8e8e8 !important; }
    html.jp-site-dark-active .tabnav__btn--active { background-color:#3a3d43 !important; }
    html.jp-site-dark-active a.tabnav__btn--active { color:#ffffff !important; }
    /* Upload: dropdowns Chosen + pílulas de checkbox/radio. A pílula ativa
       ganha borda azul pra não perder a distinção (o tema uniformiza bg). */
    html.jp-site-dark-active .chosen-drop { background-color:#2b2d31 !important; border-color:#4b4e55 !important; border-width:1px !important; border-style:solid !important; }
    html.jp-site-dark-active .chosen-results { background-color:#2b2d31 !important; }
    html.jp-site-dark-active .chosen-results li { color:#e8e8e8 !important; }
    html.jp-site-dark-active .chosen-results li.highlighted { background-color:#1e659f !important; color:#ffffff !important; }
    html.jp-site-dark-active .chosen-results li.group-result { color:#ffffff !important; background-color:#1a1b1e !important; font-weight:700 !important; text-transform:uppercase !important; font-size:11px !important; letter-spacing:.5px !important; padding:8px 10px !important; }
    html.jp-site-dark-active .chosen-results li.group-option { padding-left:18px !important; }
    html.jp-site-dark-active .chosen-single { color:#e8e8e8 !important; border-color:#4b4e55 !important; }
    html.jp-site-dark-active .chosen-single span { color:#e8e8e8 !important; }
    html.jp-site-dark-active .chosen-search input { background-color:#2b2d31 !important; color:#e8e8e8 !important; border-color:#4b4e55 !important; }
    html.jp-site-dark-active .checkbox,
    html.jp-site-dark-active .radio__pill { background-color:#2b2d31 !important; color:#e8e8e8 !important; border-color:#4b4e55 !important; }
    html.jp-site-dark-active .radio__pill--active { border-color:#2c94e8 !important; }
    html.jp-site-dark-active .checkbox span,
    html.jp-site-dark-active .checkbox label,
    html.jp-site-dark-active .radio__pill span,
    html.jp-site-dark-active .radio__pill label { color:#e8e8e8 !important; }
    /* Paginação (álbum, /new, resultados...): caixas brancas viram escuras;
       o número segue azul (regra genérica), legível no escuro. */
    html.jp-site-dark-active a.paging__pager { background-color:#2b2d31 !important; border-color:#3a3d43 !important; color:#ffffff !important; -webkit-text-fill-color:#ffffff !important; }
    /* Página atual da paginação: destaque azul. A sonda mostrou que a
       atual é a.paging__pager.paging__pager--active — o seletor leva o "a"
       junto pra ganhar da regra geral no desempate de especificidade. */
    html.jp-site-dark-active a.paging__pager.paging__pager--active,
    html.jp-site-dark-active a.paging__pager[aria-current],
    html.jp-site-dark-active span.paging__pager { background-color:#2c94e8 !important; border-color:#2c94e8 !important; color:#ffffff !important; -webkit-text-fill-color:#ffffff !important; }
    /* Graficos Highcharts (perfil, stats...): textos SVG usam fill, nao
       color — a base clareia tudo (eixos, legenda, rotulos, mapa) e o
       titulo ganha branco. */
    html.jp-site-dark-active .highcharts-container text { fill:#c3c9d2 !important; }
    html.jp-site-dark-active .highcharts-title { fill:#f2f2f2 !important; }
    /* Rotulos dos graficos (ex: nomes na pizza): o Highcharts poe halo
       branco pra contraste — no escuro, texto interno 100% preto com
       halo branco (legível na pizza azul e no fundo escuro). */
    html.jp-site-dark-active .highcharts-data-label text { fill:#000000 !important; stroke:#ffffff !important; paint-order:stroke !important; }
    /* Barra de filtros dos resultados (contagem, Modify search, Sort by). */
    html.jp-site-dark-active .show-photos-header { background-color:#26272b !important; color:#e8e8e8 !important; border-color:#3a3d43 !important; }
    html.jp-site-dark-active .show-photos-header span { color:#e8e8e8 !important; }
    /* Cards de badges + nomes (as imagens dos badges ficam intactas). */
    html.jp-site-dark-active .badge-overview__frame { background-color:#2b2d31 !important; color:#e8e8e8 !important; border-color:#3a3d43 !important; }
    html.jp-site-dark-active .badge-overview__frame span { color:#e8e8e8 !important; }
    /* Títulos avulsos com cor escura explícita (ex: upload guidelines). */
    html.jp-site-dark-active .title { color:#f2f2f2 !important; }
    /* Album/Like/Share (resultados + foto): cinza claro nos rótulos e
       ícones; branco no hover; VERDE no Like curtido (rótulo nas regras
       acima; ícone: matriz SVG constante no tom exato, regra abaixo).
       brightness(0) zera a cor original e invert(0.78) chega no cinza
       claro. Os seletores pegam o ícone em qualquer profundidade (o site
       remonta a estrutura no toggle), ::before/::after do link e do rótulo
       — i/svg vão por cor/fill exatas, o resto por filtro (todos
       idempotentes, então aninhamento não duplica o efeito). Opacidade 1
       pra o tom não variar.
       Modo claro: intocado (escopo dark). */
    html.jp-site-dark-active a.social__link,
    html.jp-site-dark-active a.social__link .social__text { color:#c3c9d2 !important; -webkit-text-fill-color:#c3c9d2 !important; }
    html.jp-site-dark-active a.social__link :not(.social__text):not(:has(.social__text)):not(i):not(svg),
    html.jp-site-dark-active a.social__link::before,
    html.jp-site-dark-active a.social__link::after,
    html.jp-site-dark-active a.social__link .social__text::before,
    html.jp-site-dark-active a.social__link .social__text::after { filter:brightness(0) invert(0.78) !important; opacity:1 !important; }
    html.jp-site-dark-active a.social__link > i,
    html.jp-site-dark-active a.social__link > svg,
    html.jp-site-dark-active a.social__link .social__text > i,
    html.jp-site-dark-active a.social__link .social__text > svg { color:#c3c9d2 !important; fill:#c3c9d2 !important; }
    /* Hover branco (ícones) só com mouse de verdade: no touch o :hover
       gruda após o toque e o ícone ficaria branco em vez de cinza. */
    @media (hover:hover) and (pointer:fine) {
    html.jp-site-dark-active a.social__link:hover :not(.social__text):not(:has(.social__text)):not(i):not(svg),
    html.jp-site-dark-active a.social__link:hover::before,
    html.jp-site-dark-active a.social__link:hover::after,
    html.jp-site-dark-active a.social__link:hover .social__text::before,
    html.jp-site-dark-active a.social__link:hover .social__text::after { filter:brightness(0) invert(1) !important; opacity:1 !important; }
    html.jp-site-dark-active a.social__link:hover > i,
    html.jp-site-dark-active a.social__link:hover > svg,
    html.jp-site-dark-active a.social__link:hover .social__text > i,
    html.jp-site-dark-active a.social__link:hover .social__text > svg { color:#ffffff !important; fill:#ffffff !important; }
    }
    /* Verde EXATO do curtido = mesmo tom do rótulo (#3ddc84): matriz
       constante, idempotente — qualquer profundidade, ::before/::after do
       link e do rótulo, qualquer formato. */
    html.jp-site-dark-active a.social__link.social__link--like.social__link--active :not(.social__text):not(:has(.social__text)),
    html.jp-site-dark-active a.social__link.social__link--like.social__link--active::before,
    html.jp-site-dark-active a.social__link.social__link--like.social__link--active::after,
    html.jp-site-dark-active a.social__link.social__link--like.social__link--active .social__text::before,
    html.jp-site-dark-active a.social__link.social__link--like.social__link--active .social__text::after { filter:url(#jp-green-dark) !important; opacity:1 !important; }
    /* Joinha injetado pela extensão nos cards do layout mobile: o arquivo
       é preto — branco (apagado) no escuro quando não-curtido, VERDE quando
       curtido. Modo claro: verde escuro quando curtido (regra no estilo
       geral), senão o preto nativo com a opacidade .4/1. */
    html.jp-site-dark-active .jp-mobile-like-btn img { filter:invert(1) !important; }
    html.jp-site-dark-active .jp-mobile-like-btn.jp-mobile-like-btn--liked img { filter:url(#jp-green-dark) !important; }
    /* Ícones de câmera do perfil (trocar avatar/capa): brancos no escuro.
       Vale só nas páginas de fotógrafo (jp-on-profile). Cobre fonte de
       ícone, SVG e imagem (brightness zera a cor, invert vira branco). */
    html.jp-site-dark-active.jp-on-profile i[class*=camera i],
    html.jp-site-dark-active.jp-on-profile svg[class*=camera i],
    html.jp-site-dark-active.jp-on-profile span[class*=camera i] { color:#ffffff !important; fill:#ffffff !important; }
    html.jp-site-dark-active.jp-on-profile img[src*=camera i] { filter:brightness(0) invert(1) !important; }
    /* Menu lateral mobile (hambúrguer): fundo escuro + links claros. */
    html.jp-site-dark-active .header__extended-section--navigation { background-color:#26272b !important; }
    html.jp-site-dark-active .header__extended-section--navigation span { color:#e8e8e8 !important; }
    html.jp-site-dark-active a.nav__link { color:#2c94e8 !important; -webkit-text-fill-color:#2c94e8 !important; }
  `;

  function ensureSiteDarkThemeStyle() {
    if (document.getElementById(SITE_DARK_STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = SITE_DARK_STYLE_ID;
    style.textContent = SITE_DARK_THEME_CSS;
    (document.head || document.documentElement).appendChild(style);
  }

  // Tabelas nativas do site (fila, photostats, Period Totals...): marca
  // pra herdar o zebra escuro. Sem isso, fileiras brancas do zebra original
  // ficam com texto claro (ilegível). Roda no init e no toggle.
  function tagNativeTablesForDark() {
    document.querySelectorAll('table:not(.jp-plus-queue-table)').forEach(table => {
      table.classList.add('jp-plus-dark-native-table');
    });
  }

  function applySiteDarkMode(isOn) {
    if (isOn) {
      ensureSiteDarkThemeStyle();
      tagNativeTablesForDark();
    }
    document.documentElement.classList.toggle(SITE_DARK_HTML_CLASS, isOn);
    document.documentElement.classList.toggle('jp-on-profile', location.pathname.startsWith('/photographer'));
    repaintLikeIcons(); // re-tinta no tom do tema (o inline guarda a url do tema anterior)
  }
  // =======================================================================
  // Painel principal
  // ---------------------------------------------------------------------
  let panelEl = null;
  let settingsMenuEl = null;
  let settingsPanelEl = null;
  let launcherHostEl = null;
  let mobileHostEl = null;
  let fabModeActive = false;
  let currentSettings = { siteDarkMode: false, queueEstimatorEnabled: true, language: 'pt-BR' };

  function buildToggleSwitch(initialOn, onChange) {
    const wrapper = document.createElement('button');
    wrapper.type = 'button';
    wrapper.setAttribute('role', 'switch');
    wrapper.setAttribute('aria-checked', String(initialOn));
    wrapper.style.cssText = `
      position:relative; width:40px; height:22px; border-radius:999px;
      border:none; cursor:pointer; padding:0; flex-shrink:0;
      background:${initialOn ? '#669DF6' : 'var(--jp-toggle-off)'};
      transition: background .15s ease;
    `;

    const thumb = document.createElement('span');
    thumb.style.cssText = `
      position:absolute; top:2px; left:${initialOn ? '20px' : '2px'};
      width:18px; height:18px; border-radius:50%; background:#fff;
      box-shadow:0 1px 2px rgba(0,0,0,0.3);
      transition: left .15s ease;
    `;
    wrapper.appendChild(thumb);

    let isOn = initialOn;
    wrapper.addEventListener('click', () => {
      isOn = !isOn;
      wrapper.setAttribute('aria-checked', String(isOn));
      wrapper.style.background = isOn ? '#669DF6' : 'var(--jp-toggle-off)';
      thumb.style.left = isOn ? '20px' : '2px';
      onChange(isOn);
    });

    return wrapper;
  }

  function buildSettingsMenu() {
    // O collapse (max-height/opacity) fica no wrapper externo (#jp-like-settings-menu,
    // já estilizado via injectStyles). O padding/borda ficam num wrapper interno —
    // assim, com max-height:0 no fechado, nada "vaza" visualmente durante a transição.
    const menu = document.createElement('div');
    menu.id = 'jp-like-settings-menu';

    const inner = document.createElement('div');
    inner.style.cssText = `
      padding-top:6px; padding-bottom:4px;
      display:flex; flex-direction:column; gap:18px;
    `;

    // --- Rótulo "Geral" (sem divisor: é a primeira seção) ---
    const generalHeader = document.createElement('div');
    generalHeader.style.cssText = `
      margin-top:0; padding-top:2px;
      font-family:Arial,Helvetica,sans-serif; font-size:11px; font-weight:600;
      letter-spacing:.6px; text-transform:uppercase; color:var(--jp-subtext);
    `;
    generalHeader.textContent = t('settingsGeneral');
    inner.appendChild(generalHeader);

    // --- Linha: idioma ---
    const languageRow = document.createElement('div');
    languageRow.style.cssText = `display:flex; align-items:center; justify-content:space-between; gap:12px; min-width:0; width:100%; box-sizing:border-box;`;

    const languageLabel = document.createElement('div');
    languageLabel.style.cssText = `font-family:Arial,Helvetica,sans-serif; font-size:14px; color:var(--jp-text); line-height:1.4; min-width:0; flex:1 1 auto; overflow-wrap:anywhere; word-break:normal;`;
    languageLabel.innerHTML = `${t('language')}<br><span style="font-size:12px; color:var(--jp-subtext);">${t('languageHelp')}</span>`;

    const languageSelect = document.createElement('select');
    languageSelect.id = 'jp-language-select';
    languageSelect.style.cssText = `font-family:Arial,Helvetica,sans-serif; font-size:13px; color:var(--jp-text); background:var(--jp-bg); border:1px solid var(--jp-border); border-radius:6px; padding:6px 8px; cursor:pointer;`;
    languageSelect.innerHTML = `<option value="pt-BR">${t('portugueseBrazil')}</option><option value="en">${t('english')}</option>`;
    languageSelect.value = currentSettings.language;
    languageSelect.addEventListener('change', () => {
      currentSettings.language = languageSelect.value === 'en' ? 'en' : 'pt-BR';
      setLanguage(currentSettings.language);
      location.reload();
    });

    languageRow.appendChild(languageLabel);
    languageRow.appendChild(languageSelect);
    inner.appendChild(languageRow);

    // --- Divisor + rótulo "Experimental" ---
    const experimentalHeader = document.createElement('div');
    experimentalHeader.style.cssText = `
      margin-top:4px; padding-top:14px;
      border-top:1px dashed var(--jp-border);
      font-family:Arial,Helvetica,sans-serif; font-size:11px; font-weight:600;
      letter-spacing:.6px; text-transform:uppercase; color:var(--jp-subtext);
    `;
    experimentalHeader.textContent = t('experimental');
    inner.appendChild(experimentalHeader);

    // --- Linha: modo escuro do SITE (experimental) ---
    const siteDarkRow = document.createElement('div');
    siteDarkRow.style.cssText = `
      display:flex; align-items:center; justify-content:space-between; gap:12px; min-width:0; width:100%; box-sizing:border-box;
    `;

    const siteDarkLabel = document.createElement('div');
    siteDarkLabel.style.cssText = `
      font-family:Arial,Helvetica,sans-serif; font-size:14px; color:var(--jp-text); line-height:1.4; min-width:0; flex:1 1 auto; overflow-wrap:anywhere; word-break:normal;
    `;
    siteDarkLabel.innerHTML = `${t('siteDarkMode')}<br><span style="font-size:12px; color:var(--jp-subtext);">${t('siteDarkModeHelp')}</span>`;

    const siteDarkToggle = buildToggleSwitch(currentSettings.siteDarkMode, (isOn) => {
      currentSettings.siteDarkMode = isOn;
      setSiteDarkMode(isOn);
      applySiteDarkMode(isOn);
      if (panelEl) panelEl.classList.toggle('jp-dark', isOn);
      if (settingsPanelEl) settingsPanelEl.classList.toggle('jp-dark', isOn);
      document.getElementById('jp-plus-mobile-submenu')?.classList.toggle('jp-dark', isOn);
      if (mobileHostEl) mobileHostEl.classList.toggle('jp-dark', isOn);
    });

    siteDarkRow.appendChild(siteDarkLabel);
    siteDarkRow.appendChild(siteDarkToggle);
    inner.appendChild(siteDarkRow);

    // --- Linha: estimador de dias na fila (experimental) ---
    // Só é relevante em queue.php, mas o toggle fica visível em qualquer
    // página (mesmo padrão do modo escuro do site) — assim dá pra
    // desligar/religar sem precisar estar na página da fila. Requer
    // recarregar a página pra aplicar, porque o corpo do painel é montado
    // uma vez em buildPanel() a partir do valor lido em init().
    const queueEstRow = document.createElement('div');
    queueEstRow.style.cssText = `
      display:flex; align-items:center; justify-content:space-between; gap:12px; min-width:0; width:100%; box-sizing:border-box;
    `;

    const queueEstLabel = document.createElement('div');
    queueEstLabel.style.cssText = `
      font-family:Arial,Helvetica,sans-serif; font-size:14px; color:var(--jp-text); line-height:1.4; min-width:0; flex:1 1 auto; overflow-wrap:anywhere; word-break:normal;
    `;
    queueEstLabel.innerHTML = `${t('queueEstimator')}<br><span style="font-size:12px; color:var(--jp-subtext);">${t('queueEstimatorHelp')}</span>`;

    const queueEstToggle = buildToggleSwitch(currentSettings.queueEstimatorEnabled, (isOn) => {
      currentSettings.queueEstimatorEnabled = isOn;
      setQueueEstimatorEnabled(isOn);
    });

    queueEstRow.appendChild(queueEstLabel);
    queueEstRow.appendChild(queueEstToggle);
    inner.appendChild(queueEstRow);

    const historyHeader = document.createElement('div');
    historyHeader.style.cssText = `
      margin-top:4px; padding-top:14px;
      border-top:1px dashed var(--jp-border);
      font-family:Arial,Helvetica,sans-serif; font-size:11px; font-weight:600;
      letter-spacing:.6px; text-transform:uppercase; color:var(--jp-subtext);
    `;
    historyHeader.textContent = t('historyData');
    inner.appendChild(historyHeader);

    const historyHelp = document.createElement('div');
    historyHelp.style.cssText = `font-family:Arial,Helvetica,sans-serif; font-size:12px; color:var(--jp-subtext); line-height:1.4;`;
    historyHelp.textContent = t('historyDataHelp');
    inner.appendChild(historyHelp);

    const historyActions = document.createElement('div');
    historyActions.style.cssText = `display:flex; flex-wrap:wrap; gap:8px; align-items:center;`;

    const mkBtn = (label) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = label;
      b.style.cssText = `
        font-family:Arial,Helvetica,sans-serif; font-size:13px; cursor:pointer;
        color:var(--jp-text); background:var(--jp-bg); border:1px solid var(--jp-border);
        border-radius:6px; padding:7px 10px;
      `;
      return b;
    };

    const exportBtn = mkBtn(t('exportHistory'));
    const importBtn = mkBtn(t('importHistory'));
    const importInput = document.createElement('input');
    importInput.type = 'file';
    importInput.accept = 'application/json,.json';
    importInput.hidden = true;
    const historyMsg = document.createElement('div');
    historyMsg.style.cssText = `font-family:Arial,Helvetica,sans-serif; font-size:12px; color:var(--jp-subtext); min-height:1.2em;`;

    exportBtn.addEventListener('click', async () => {
      const stats = await loadQueueDailyStats();
      const blob = new Blob([JSON.stringify({
        format: 'JetPhotos+', type: 'queue-history', version: 2,
        exportedAt: new Date().toISOString(), history: stats
      }, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `jetphotos-plus-history-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 500);
      historyMsg.textContent = t('historyExported');
    });

    importBtn.addEventListener('click', () => importInput.click());
    importInput.addEventListener('change', async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      try {
        const payload = JSON.parse(await file.text());
        const imported = payload?.history;
        if (!imported || typeof imported !== 'object') throw new Error('invalid');
        const current = await loadQueueDailyStats();
        const merged = { ...current };
        const keys = Object.keys(imported).filter(k => k !== '__meta' && /^\d{4}-\d{2}-\d{2}$/.test(k));
        for (const key of keys) merged[key] = imported[key];
        if (imported.__meta) {
          const currentAt = Number(current.__meta?.lastObservedAtMs || 0);
          const importedAt = Number(imported.__meta?.lastObservedAtMs || 0);
          merged.__meta = importedAt > currentAt
            ? { ...(current.__meta || {}), ...imported.__meta }
            : (current.__meta || imported.__meta);
        }
        const trimmedKeys = Object.keys(merged).filter(k => k !== '__meta' && /^\d{4}-\d{2}-\d{2}$/.test(k)).sort();
        for (const oldKey of trimmedKeys.slice(0, Math.max(0, trimmedKeys.length - 60))) delete merged[oldKey];
        await setExtensionStorage({ [STORAGE_KEY_QUEUE_DAILY_STATS]: merged });
        try {
          const action = JP_WEBEXT?.action || JP_WEBEXT?.browserAction;
          action?.setBadgeText?.({ text: String(Math.min(Object.keys(merged).filter(k => k !== '__meta').length, 99)) });
          action?.setBadgeBackgroundColor?.({ color: '#4299dc' });
        } catch (_) {}
        historyMsg.textContent = t('historyImported', keys.length);
      } catch (_) {
        historyMsg.textContent = t('historyImportFail');
      }
      e.target.value = '';
    });

    historyActions.appendChild(exportBtn);
    historyActions.appendChild(importBtn);
    historyActions.appendChild(importInput);
    inner.appendChild(historyActions);
    inner.appendChild(historyMsg);

    menu.appendChild(inner);

    return menu;
  }

  function findHeaderIntegrationTarget() {
    // O JetPhotos mantém a área da conta em uma navegação separada.
    // Inserimos o JetPhotos+ na MESMA lista do usuário, imediatamente após
    // o item do e-mail/nome. Assim ele herda a geometria do header e o
    // submenu pode se comportar como os dropdowns nativos do site.
    const accountNav = document.querySelector(
      '#nav-logged-in, nav[id*="logged-in"], [id*="nav-logged-in"]'
    );
    if (!accountNav) return null;

    const usernameList = accountNav.querySelector(
      'ul.nav-desktop__list--username, ul[class*="list--username"], ul'
    );
    if (usernameList) {
      const accountItem = usernameList.querySelector(
        'li.nav-desktop__item--menu, li[class*="item--menu"], li'
      );
      if (accountItem) {
        const reference = accountItem.querySelector('a, span') || accountItem;
        return {
          container: usernameList,
          after: accountItem,
          reference,
          mode: 'account-list'
        };
      }
    }

    const parent = accountNav.parentElement;
    if (parent) {
      return {
        container: parent,
        after: accountNav,
        reference: accountNav.querySelector('a, span, li') || accountNav,
        mode: 'after-account-nav'
      };
    }

    return null;
  }

  function styleLauncherFromReference(launcher, host, reference, container) {
    const ref = reference && reference.nodeType === 1 ? reference : container;
    const rs = getComputedStyle(ref);
    const cs = getComputedStyle(container);

    launcher.style.fontFamily = rs.fontFamily || cs.fontFamily;
    launcher.style.fontSize = rs.fontSize || cs.fontSize;
    launcher.style.fontWeight = rs.fontWeight || cs.fontWeight;
    launcher.style.letterSpacing = rs.letterSpacing || cs.letterSpacing;
    launcher.style.lineHeight = rs.lineHeight || 'normal';
    launcher.style.color = rs.color || cs.color;
    launcher.style.height = rs.height && rs.height !== 'auto'
      ? rs.height
      : (cs.height !== 'auto' ? cs.height : '60px');
    launcher.style.paddingTop = rs.paddingTop;
    launcher.style.paddingBottom = rs.paddingBottom;
    launcher.style.paddingLeft = '10px';
    launcher.style.paddingRight = '10px';
    launcher.style.backgroundColor = 'transparent';
    launcher.style.border = '0';
    launcher.style.margin = '0';
    host.style.height = launcher.style.height;
    host.style.lineHeight = launcher.style.lineHeight;
  }

  // Constrói o menu de configs uma vez só, onde quer que o painel esteja.
  function ensureSettingsMenu() {
    if (!settingsMenuEl && settingsPanelEl) {
      const body = settingsPanelEl.querySelector('.jp-settings-body');
      if (body) {
        body.appendChild(buildSettingsMenu());
        settingsMenuEl = body.firstElementChild;
      }
    }
  }

  function updateBackdrop() {
    const backdrop = document.getElementById('jp-plus-backdrop');
    if (!backdrop) return;
    // O backdrop só deve ser mostrado quando o SUBMENU ou mobile menu
    // estão abertos (pra fechar ao clicar fora). Quando o SETTINGS PANEL
    // está aberto, o backdrop NÃO deve ficar visível — senão ele fica
    // por cima do painel e captura os cliques (bug no desktop devido a
    // stacking contexts diferentes).
    const settingsOpen = launcherHostEl?.classList.contains('jp-settings-open') ||
      mobileHostEl?.classList.contains('jp-settings-open');
    const menuOpen = mobileHostEl?.classList.contains('jp-mobile-menu-open');
    const open = !settingsOpen && menuOpen;
    backdrop.classList.toggle('jp-backdrop-show', !!open);
  }

  function setSettingsOpen(open) {
    const host = fabModeActive && mobileHostEl ? mobileHostEl : launcherHostEl;
    if (launcherHostEl) launcherHostEl.classList.remove('jp-settings-open');
    if (mobileHostEl) mobileHostEl.classList.remove('jp-settings-open');
    if (open && host) host.classList.add('jp-settings-open');
    updateBackdrop();
    installClickOutsideSettings(open);
  }

  // Fecha o settings ao clicar fora dele (no desktop). Usa mousedown no
  // document em vez do backdrop, porque o backdrop fica preso num
  // stacking context diferente do header do JetPhotos e acaba cobrindo
  // o painel. Aqui, verificamos se o clique foi fora do launcherHostEl
  // e fora do settingsPanel (que pode estar no mobileHostEl).
  let clickOutsideSettingsHandler = null;
  function installClickOutsideSettings(active) {
    // Remove handler anterior, se existir
    if (clickOutsideSettingsHandler) {
      document.removeEventListener('mousedown', clickOutsideSettingsHandler, true);
      clickOutsideSettingsHandler = null;
    }
    if (!active) return;
    // Usa capture:true pra pegar o evento antes de qualquer stopPropagation
    // que os próprios elementos da extensão possam ter.
    clickOutsideSettingsHandler = (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      // Se clicou dentro do launcherHostEl (que contém o settings panel
      // no desktop) ou dentro do mobileHostEl (que contém no mobile),
      // não fecha.
      if (launcherHostEl?.contains(target)) return;
      if (mobileHostEl?.contains(target)) return;
      // Clique foi fora — fecha tudo.
      closeAllPlus();
    };
    // setTimeout pra não pegar o próprio clique que abriu o settings
    setTimeout(() => {
      if (clickOutsideSettingsHandler) {
        document.addEventListener('mousedown', clickOutsideSettingsHandler, true);
      }
    }, 0);
  }

  // Docagem do FAB: ao fechar o menu, o botão fica visível por um instante
  // e depois volta sozinho pra lateral (meio escondido + translúcido).
  let fabDockTimer = null;
  function scheduleFabDock() {
    if (!mobileHostEl || typeof window === 'undefined') return;
    if (fabDockTimer) window.clearTimeout(fabDockTimer);
    fabDockTimer = window.setTimeout(() => {
      fabDockTimer = null;
      if (mobileHostEl && !mobileHostEl.classList.contains('jp-mobile-menu-open')) mobileHostEl.classList.add('jp-fab-docked');
    }, 1400);
  }
  function undockFab() {
    if (fabDockTimer && typeof window !== 'undefined') { window.clearTimeout(fabDockTimer); fabDockTimer = null; }
    if (mobileHostEl) mobileHostEl.classList.remove('jp-fab-docked');
  }
  function setMobileMenuOpen(open) {
    if (!mobileHostEl) return;
    if (open) {
      if (launcherHostEl) launcherHostEl.classList.remove('jp-settings-open');
      mobileHostEl.classList.remove('jp-settings-open');
    }
    mobileHostEl.classList.toggle('jp-mobile-menu-open', open);
    if (open) undockFab();
    else scheduleFabDock();
    updateBackdrop();
  }

  function closeAllPlus() {
    if (launcherHostEl) launcherHostEl.classList.remove('jp-settings-open');
    if (mobileHostEl) {
      mobileHostEl.classList.remove('jp-settings-open');
      mobileHostEl.classList.remove('jp-mobile-menu-open');
    }
    installClickOutsideSettings(false);
    scheduleFabDock();
    updateBackdrop();
  }

  // Modo FAB: o launcher do header não está visível (layout mobile), então
  // o painel de configs mora no host mobile. Reavaliado no resize.
  function applyFabMode() {
    if (!launcherHostEl || !mobileHostEl || !settingsPanelEl) return;
    const fab = launcherHostEl.offsetParent === null;
    fabModeActive = fab;
    mobileHostEl.style.display = fab ? '' : 'none';
    const target = fab ? mobileHostEl : launcherHostEl;
    if (settingsPanelEl.parentElement !== target) target.appendChild(settingsPanelEl);
    const wasOpen = (launcherHostEl.classList.contains('jp-settings-open') ||
      mobileHostEl.classList.contains('jp-settings-open'));
    launcherHostEl.classList.remove('jp-settings-open');
    mobileHostEl.classList.remove('jp-settings-open');
    if (wasOpen) target.classList.add('jp-settings-open');
    if (!fab) mobileHostEl.classList.remove('jp-mobile-menu-open');
    updateBackdrop();
  }

  let fabResizeTimer = null;
  function installFabModeWatcher() {
    if (document.documentElement.dataset.jpFabWatcher === '1') return;
    document.documentElement.dataset.jpFabWatcher = '1';
    window.addEventListener('resize', () => {
      clearTimeout(fabResizeTimer);
      fabResizeTimer = setTimeout(applyFabMode, 200);
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') closeAllPlus();
    });
  }

  // Host mobile: FAB redondo com a logo + submenu igual ao do PC. O painel
  // de configs (único) muda pra cá quando o modo FAB está ativo.
  function buildMobileHost() {
    document.querySelectorAll('#jp-plus-mobile-host').forEach(el => el.remove());
    let backdrop = document.getElementById('jp-plus-backdrop');
    if (!backdrop) {
      backdrop = document.createElement('button');
      backdrop.type = 'button';
      backdrop.id = 'jp-plus-backdrop';
      backdrop.setAttribute('tabindex', '-1');
      backdrop.setAttribute('aria-hidden', 'true');
      document.body.appendChild(backdrop);
      backdrop.addEventListener('click', () => closeAllPlus());
    }
    const mhost = document.createElement('div');
    mhost.id = 'jp-plus-mobile-host';
    mhost.style.display = 'none';
    const fab = document.createElement('button');
    fab.type = 'button';
    fab.id = 'jp-plus-mobile-fab';
    fab.setAttribute('aria-label', t('settings'));
    fab.title = 'JetPhotos+';
    const logo = document.createElement('img');
    logo.src = getExtensionURL('icons/logo.png');
    logo.alt = '';
    logo.setAttribute('aria-hidden', 'true');
    fab.appendChild(logo);
    fab.addEventListener('click', event => {
      event.stopPropagation();
      const anyOpen = mhost.classList.contains('jp-mobile-menu-open') || mhost.classList.contains('jp-settings-open');
      if (anyOpen) closeAllPlus();
      else setMobileMenuOpen(true);
    });
    const submenu = document.createElement('div');
    submenu.id = 'jp-plus-mobile-submenu';
    submenu.setAttribute('role', 'menu');
    submenu.innerHTML = `
      <a href="https://github.com/samuelffer/jetphotosplus/releases" id="jp-plus-mobile-releases-link" role="menuitem" target="_blank" rel="noopener noreferrer">${t('viewReleases')}</a>
      <a href="https://github.com/samuelffer/jetphotosplus/issues" id="jp-plus-mobile-issues-link" role="menuitem" target="_blank" rel="noopener noreferrer">${t('reportIssue')}</a>
      <a href="https://samuelffer.github.io/jetphotosplus/" id="jp-plus-mobile-about-link" role="menuitem" target="_blank" rel="noopener noreferrer">${t('aboutJetPhotosPlus')}</a>
      <a href="${DONATE_URL}" id="jp-plus-mobile-donate-link" role="menuitem" target="_blank" rel="noopener noreferrer"><svg width="16" height="16" viewBox="0 0 24 24" fill="#e74c3c" style="vertical-align:middle;margin-right:6px"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>${t('donate')}</a>
      <a href="#" id="jp-plus-mobile-settings-link" role="menuitem">${t('settings')}</a>
    `;
    if (currentSettings.siteDarkMode) submenu.classList.add('jp-dark');
    if (currentSettings.siteDarkMode) mhost.classList.add('jp-dark');
    submenu.querySelector('#jp-plus-mobile-settings-link').addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      ensureSettingsMenu();
      setMobileMenuOpen(false);
      setSettingsOpen(true);
    });
    const fabWrap = document.createElement('span');
    fabWrap.id = 'jp-plus-mobile-fab-wrap';
    fabWrap.appendChild(fab);
    mhost.appendChild(fabWrap);
    mhost.appendChild(submenu);
    mhost.classList.add('jp-fab-docked');
    document.body.appendChild(mhost);
    mobileHostEl = mhost;
    installFabModeWatcher();
  }

  function buildPanel(isPhotoContext, isQueueMode) {
    injectStyles();

    const headerTarget = findHeaderIntegrationTarget();
    if (!headerTarget) {
      console.warn('[JetPhotos+] Header de conta não encontrado; launcher adiado.');
      return false;
    }

    document.querySelectorAll('#jp-plus-launcher-host').forEach(el => el.remove());
    document.querySelectorAll('#jp-like-widget-bubble').forEach(el => el.remove());
    document.querySelectorAll('#jp-plus-settings-panel').forEach(el => el.remove());
    document.querySelectorAll('#jp-plus-mobile-host').forEach(el => el.remove());
    mobileHostEl = null;

    const host = document.createElement(headerTarget.mode === 'account-list' ? 'li' : 'span');
    host.id = 'jp-plus-launcher-host';
    launcherHostEl = host;
    if (headerTarget.mode === 'account-list') host.className = 'nav-desktop__item';
    // Impede que eventos de mouse propaguem para o header do JetPhotos,
    // que pode ter listeners globais fechando menus dropdown (especialmente
    // no desktop, onde o launcher é um <li> na nav principal).
    ['mousedown', 'pointerdown'].forEach(eventType => {
      host.addEventListener(eventType, event => event.stopPropagation());
    });

    const launcher = document.createElement('span');
    launcher.id = 'jp-plus-launcher';
    launcher.setAttribute('role', 'menuitem');
    launcher.setAttribute('tabindex', '0');
    launcher.setAttribute('aria-label', 'JetPhotos+');
    launcher.setAttribute('title', 'JetPhotos+');
    const launcherLogo = document.createElement('img');
    launcherLogo.className = 'jp-launcher-logo';
    launcherLogo.src = getExtensionURL('icons/logo.png');
    launcherLogo.alt = '';
    launcherLogo.setAttribute('aria-hidden', 'true');
    launcher.appendChild(launcherLogo);
    host.appendChild(launcher);

    // O launcher não tem ação de clique: o comportamento é exclusivamente
    // hover/foco, igual aos menus nativos do JetPhotos.
    const submenu = document.createElement('div');
    submenu.id = 'jp-plus-submenu';
    submenu.setAttribute('role', 'menu');
    submenu.innerHTML = `
      <a href="https://github.com/samuelffer/jetphotosplus/releases" id="jp-plus-releases-link" role="menuitem" target="_blank" rel="noopener noreferrer">${t('viewReleases')}</a>
      <a href="https://github.com/samuelffer/jetphotosplus/issues" id="jp-plus-issues-link" role="menuitem" target="_blank" rel="noopener noreferrer">${t('reportIssue')}</a>
      <a href="https://samuelffer.github.io/jetphotosplus/" id="jp-plus-about-link" role="menuitem" target="_blank" rel="noopener noreferrer">${t('aboutJetPhotosPlus')}</a>
      <a href="${DONATE_URL}" id="jp-plus-donate-link" role="menuitem" target="_blank" rel="noopener noreferrer"><svg width="16" height="16" viewBox="0 0 24 24" fill="#e74c3c" style="vertical-align:middle;margin-right:6px"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>${t('donate')}</a>
      <a href="#" id="jp-plus-settings-link" role="menuitem">${t('settings')}</a>
    `;
    if (currentSettings.siteDarkMode) submenu.classList.add('jp-dark');
    host.appendChild(submenu);

    const settingsPanel = document.createElement('div');
    settingsPanel.id = 'jp-plus-settings-panel';
    settingsPanel.setAttribute('role', 'dialog');
    settingsPanel.setAttribute('aria-label', t('settings'));
    if (currentSettings.siteDarkMode) settingsPanel.classList.add('jp-dark');
    // Impede que cliques dentro do painel propaguem para o header do
    // JetPhotos, que pode ter listeners globais fechando menus dropdown.
    // Usa múltiplos eventos (click, mousedown, pointerdown) porque o
    // JetPhotos pode estar usando qualquer um deles.
    ['click', 'mousedown', 'pointerdown'].forEach(eventType => {
      settingsPanel.addEventListener(eventType, event => event.stopPropagation());
    });
    const settingsTitle = document.createElement('div');
    settingsTitle.className = 'jp-settings-title';
    settingsTitle.innerHTML = `<span>${t('settings')}</span><button type="button" class="jp-settings-close" aria-label="${t('close')}">×</button>`;
    const settingsBody = document.createElement('div');
    settingsBody.className = 'jp-settings-body';
    settingsPanel.appendChild(settingsTitle);
    settingsPanel.appendChild(settingsBody);
    host.appendChild(settingsPanel);
    settingsPanelEl = settingsPanel;

    const settingsLink = submenu.querySelector('#jp-plus-settings-link');
    settingsLink.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      ensureSettingsMenu();
      setSettingsOpen(true);
    });

    settingsTitle.querySelector('.jp-settings-close').addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      setSettingsOpen(false);
      if (fabModeActive) setMobileMenuOpen(true);
    });

    if (headerTarget.after && headerTarget.after.parentElement === headerTarget.container) {
      headerTarget.container.insertBefore(host, headerTarget.after.nextElementSibling);
    } else {
      headerTarget.container.appendChild(host);
    }
    styleLauncherFromReference(launcher, host, headerTarget.reference, headerTarget.container);
    buildMobileHost();
    applyFabMode();

    panelEl = submenu;

    // A ferramenta de curtidas é a bolha no canto inferior direito — o único
    // UI de likes, em qualquer tela. Ela só existe nas páginas que realmente
    // contêm fotos com ação de Like.
    if (isPhotoContext && !isQueueMode) {
      // Criada aqui pra já existir antes do primeiro refresh() tentar
      // atualizar o contador.
      const bubble = document.createElement('button');
      bubble.type = 'button';
      bubble.id = 'jp-like-widget-bubble';
      bubble.title = t('likeMissing');
      bubble.setAttribute('aria-label', t('analyzing'));
      bubble.innerHTML = `
        <span class="jp-bubble-ring-wrap" aria-hidden="true">
          <svg class="jp-bubble-ring" viewBox="0 0 28 28"><circle class="jp-bubble-ring-track" cx="14" cy="14" r="12"></circle><circle class="jp-bubble-ring-fill" id="jp-bubble-ring-fill" cx="14" cy="14" r="12"></circle></svg>
          <svg class="jp-bubble-thumb" viewBox="0 1 26 26"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <svg class="jp-bubble-check" viewBox="0 0 28 28"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" fill="#22c55e" stroke="#22c55e" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </span>
        <span id="jp-like-widget-bubble-count">\u2026</span>
        <span id="jp-like-widget-bubble-label" class="jp-bubble-label"></span>`;
      bubble.addEventListener('click', () => {
        // O toque curte tudo direto. Com leva em andamento, ignora; com a
        // bolha verde (tudo curtido), avisa num toast em vez de calar.
        if (isLiking) return;
        if ((lastBubbleMissing ?? 0) <= 0) {
          if (lastBubbleMissing !== null) showLikeToast(t('allLikedToast'));
          return;
        }
        runLikeAllBatch();
      });
      document.body.appendChild(bubble);
    }

    settingsMenuEl = null;
    return true;
  }

  // Última contagem vista pela bolha (null = ainda analisando). É o que o
  // toque na bolha consulta pra decidir se há o que curtir.
  let lastBubbleMissing = null;

  // Atualiza o contador da bolha. null = ainda analisando (mostra …).
  // Anel de progresso da bolha: 0 = vazio, 1 = fechado verde.
  const BUBBLE_RING_C = 75.4; // 2π×12, mesmo r do círculo no SVG (ver CSS)
  function setBubbleProgress(frac) {
    const fill = document.getElementById('jp-bubble-ring-fill');
    if (!fill) return;
    const clamped = Math.max(0, Math.min(1, frac || 0));
    // Esconde o arco zerado: com ponta redonda, um arco de comprimento 0
    // ainda renderiza como um pontinho verde no topo do anel.
    fill.style.opacity = clamped <= 0 ? '0' : '1';
    fill.style.strokeDashoffset = String(BUBBLE_RING_C * (1 - clamped));
  }

  // Toast de aviso da bolha (ex: tudo já curtido). Um de cada vez: se já
  // houver um visível, só troca o texto e reinicia o temporizador.
  let likeToastTimer = null;
  function showLikeToast(message) {
    let toast = document.getElementById('jp-like-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'jp-like-toast';
      toast.setAttribute('role', 'status');
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    // Recomeça a transição mesmo quando o toast já estava visível.
    toast.classList.remove('jp-toast-show');
    void toast.offsetWidth;
    toast.classList.add('jp-toast-show');
    clearTimeout(likeToastTimer);
    likeToastTimer = setTimeout(() => toast.classList.remove('jp-toast-show'), 2500);
  }

  function updateBubble(missingOrNull) {
    const bubble = document.getElementById('jp-like-widget-bubble');
    const count = document.getElementById('jp-like-widget-bubble-count');
    const label = document.getElementById('jp-like-widget-bubble-label');
    if (!bubble || !count) return;
    if (missingOrNull == null) {
      lastBubbleMissing = null;
      setBubbleProgress(0);
      count.textContent = '\u2026';
      bubble.classList.remove('jp-bubble-done');
      bubble.setAttribute('aria-label', t('analyzing'));
      if (label) { label.textContent = ''; label.style.display = 'none'; }
      return;
    }
    lastBubbleMissing = missingOrNull;
    const done = missingOrNull <= 0;
    setBubbleProgress(done ? 1 : 0);
    count.textContent = done ? '0' : String(missingOrNull);
    bubble.classList.toggle('jp-bubble-done', done);
    bubble.setAttribute('aria-label', done
      ? (currentSettings.language === 'en' ? 'All liked!' : 'Tudo curtido!')
      : `${missingOrNull} ${t('missing')}`);
    bubble.title = done
      ? (currentSettings.language === 'en' ? 'All liked!' : 'Tudo curtido!')
      : t('likeMissing');
    // Rótulo do desktop largo ("10 faltando"); some quando concluído (o selo basta).
    if (label) {
      label.textContent = done ? '' : t('missing');
      label.style.display = done ? 'none' : '';
    }
  }

  // Placar das curtidas: a bolha é o único mostrador, então é só alimentá-la.
  function updateStatus(cards, missing) {
    // Durante a leva, o clickNext já atualiza a bolha a cada clique — não
    // deixe esses refreshes brigarem com a contagem regressiva.
    if (isLiking) return;
    updateBubble(cards.length ? missing : null);
  }

  function highlightCard(card, liked) {
    if (!card) return;

    // Outline removido a pedido do usuário — as linhas vermelhas ao redor
    // das fotos não curtidas eram confusas. Se um dia quiser voltar, é só
    // descomentar as linhas abaixo.
    // const wanted = liked ? 'none' : '3px solid #ff5f5f';
    // if (card.style.outline !== wanted) {
    //   card.style.transition = 'outline-color .2s ease';
    //   card.style.outline = wanted;
    //   card.style.outlineOffset = '2px';
    // }

    // Remove outline se existir (caso venha de versão anterior)
    if (card.style.outline && card.style.outline !== 'none') {
      card.style.outline = 'none';
    }
  }

  let isRefreshing = false;

  function refresh() {
    if (isRefreshing) return; // evita reentrância
    // Durante a leva em massa, pula: cada confirmação de rede + cada mutação
    // do site pediria uma varredura completa (getBoundingClientRect/
    // getComputedStyle por card = reflow forçado), e no celular isso somava
    // dezenas de reflows seguidos e travava a página. Cada joinha já se
    // atualiza sozinho via syncPhotoVisualById (mirado, barato), e o fim da
    // leva chama refresh() de novo pra assentar contador e realces.
    if (isLiking) return null;
    isRefreshing = true;

    // Desliga o observer enquanto mexemos no DOM/estilo, e religa depois.
    // O finally abaixo garante que essas duas operações nunca fiquem
    // esquecidas caso findPhotoCards/isAlreadyLiked lance uma exceção.
    if (observerRef) observerRef.disconnect();

    try {
      injectMobileLikeButtons();
      const cards = findPhotoCards();
      let missing = 0;
      cards.forEach(({ anchor, card }) => {
        const liked = isAlreadyLiked(anchor, card);
        highlightCard(card, liked);
        // O botão injetado no layout mobile também é um "anchor" normal
        // aqui (ver findPhotoCards) — só precisa, além da classe de
        // destaque do card, ter seu próprio ícone sincronizado a cada
        // scan. Isso corrige o ícone sozinho mesmo que uma confirmação de
        // rede anterior não tenha atualizado ele por qualquer motivo.
        if (anchor?.classList?.contains(MOBILE_LIKE_BTN_CLASS)) {
          applyMobileButtonState(anchor, liked);
        } else if (anchor) {
          if (liked) forceLikedVisual(anchor); else revokeLikedVisual(anchor);
        }
        if (!liked) missing++;
      });

      repaintLikeIcons();
      updateStatus(cards, missing);
      return { cards, missing };
    } catch (error) {
      console.error('[JetPhotos+] Erro durante refresh():', error);
      return null;
    } finally {
      if (observerRef && observeTarget) {
        observerRef.observe(observeTarget, { childList: true, subtree: true });
      }
      isRefreshing = false;
    }
  }

  // Debounce: só executa o refresh depois que o DOM ficar "quieto" por
  // DEBOUNCE_MS. Evita rodar o scan dezenas/centenas de vezes por segundo
  // enquanto a página ainda está carregando imagens/spinners.
  const DEBOUNCE_MS = 400;
  let debounceTimer = null;
  function scheduleRefresh() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(refresh, DEBOUNCE_MS);
  }

  // Pequena pausa entre cada clique de "curtir": evita disparar dezenas de
  // cliques no mesmo instante (mais parecido com uso normal, e reduz
  // qualquer chance do site tratar como automação/flood). É curto de
  // propósito — a ideia é só "não ser instantâneo", não deixar lento.
  const LIKE_CLICK_DELAY_MS = 12;
  const LIKE_CLICK_JITTER_MS = 10; // variação aleatória somada ao delay, pra não ficar um intervalo perfeitamente uniforme
  let isLiking = false;

  // onDone é chamado quando todos os cliques da leva atual terminam
  // (sucesso ou lista vazia). Retorna de imediato a quantidade de fotos
  // que serão clicadas, mesmo os cliques em si sendo espaçados no tempo.
  function likeAllMissing(onDone) {
    if (isLiking) return 0; // já tem uma leva rodando, ignora clique duplo
    const cards = findPhotoCards();
    const targets = cards
      .filter(({ anchor, card }) => !isAlreadyLiked(anchor, card))
      .map(({ anchor }) => anchor);

    if (!targets.length) {
      if (onDone) onDone(0);
      return 0;
    }

    isLiking = true;
    let i = 0;
    function clickNext() {
      if (i >= targets.length) {
        isLiking = false;
        setTimeout(refresh, 500); // dá um tempo pro site atualizar o estado visual do último clique
        if (onDone) onDone(targets.length);
        return;
      }
      // Um .click() que lance (handler do próprio site) não pode quebrar a
      // corrente da leva — essa foto fica pra próxima e o resto continua.
      try {
        targets[i].click();
      } catch (clickError) {
        console.error('[JetPhotos+] Clique ignorado (handler do site lançou):', clickError);
      }
      i++;
      updateBubble(targets.length - i);
      setBubbleProgress(i / targets.length);
      const delay = LIKE_CLICK_DELAY_MS + Math.random() * LIKE_CLICK_JITTER_MS;
      setTimeout(clickNext, delay);
    }
    clickNext();

    return targets.length;
  }

  // Dispara a leva de "curtir faltantes" a partir da bolha. Todo o feedback
  // é na própria bolha (contagem regressiva + anel + borda verde + selo).
  function runLikeAllBatch() {
    if (isLiking) return;
    let total = 0;
    try {
      total = likeAllMissing(doneCount => {
        // onDone: a leva terminou (doneCount=0 se não havia nada faltando).
        updateBubble(0); // bolha vira só o selo verde (o refresh final confirma)
        document.getElementById('jp-like-widget-bubble')?.classList.remove('jp-bubble-liking');
      });
    } catch (error) {
      console.error('[JetPhotos+] Falha ao iniciar a leva de curtidas:', error);
      document.getElementById('jp-like-widget-bubble')?.classList.remove('jp-bubble-liking');
      return;
    }
    document.getElementById('jp-like-widget-bubble')?.classList.toggle('jp-bubble-liking', total > 0);
  }

  // =======================================================================
  // >>> INÍCIO DO BLOCO EXPERIMENTAL: ESTIMADOR DE FILA (queue.php) <<<
  // -----------------------------------------------------------------------
  // Marcado como experimental (toggle em Configurações > Experimental,
  // STORAGE_KEY_QUEUE_ESTIMATOR_ENABLED) porque depende de "adivinhar" a
  // estrutura de texto de uma página que não controlamos — se o JetPhotos
  // mudar o layout de "Overall Queue Status", a extração pode quebrar de
  // novo (como aconteceu com o bug do período/select corrigido nesta
  // revisão). O toggle deixa fácil desligar o recurso pro usuário sem
  // precisar reinstalar nada; e, pra quem for mexer no código depois,
  // remover o recurso por completo é só apagar tudo entre este marcador e
  // o "FIM DO BLOCO EXPERIMENTAL" mais abaixo, tirar as 2 chamadas
  // marcadas com [EXPERIMENTAL] em init() e a linha do toggle em
  // buildSettingsMenu() — nenhuma outra parte do arquivo depende disso.
  // -----------------------------------------------------------------------
  // Ideia: a própria página já informa quantas fotos foram PROCESSADAS por
  // dia (coluna "processed" de cada data em "Overall Queue Status"). Isso
  // já É o throughput diário — não precisamos diffar snapshots entre
  // visitas pra descobrir o ritmo, só ler e tirar a média dos últimos dias
  // completos (o dia de hoje é sempre parcial, então é excluído da média
  // pra não puxar o número pra baixo artificialmente).
  //
  //   dias_estimados = fotos_à_frente_na_fila / média_diária_processada
  //
  // O histórico é persistido em chrome.storage.local porque o site só
  // expõe os últimos 7 dias — guardando cada dia visto, a amostra cresce
  // com o tempo mesmo que você não abra a extensão todo dia.
  // =======================================================================

  const MONTHS_EN = ['January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'];

  function isQueuePage() {
    return location.pathname.startsWith('/members/queue.php');
  }

  // Converte "15 August 2026" -> "2026-08-15" (chave ordenável e estável
  // pra usar como índice do histórico). Retorna null se o texto não bater
  // com o formato esperado.
  function dateLabelToKey(label) {
    const m = label.match(/^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})$/);
    if (!m) return null;
    const day = parseInt(m[1], 10);
    const monthIdx = MONTHS_EN.findIndex(mo => mo.toLowerCase() === m[2].toLowerCase());
    if (monthIdx === -1) return null;
    const year = m[3];
    return `${year}-${String(monthIdx + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  }

  // Data de "hoje" pelo RELÓGIO DO USUÁRIO (fuso local do computador), não
  // o do servidor do JetPhotos. Usada só pra exibição/comparação — o
  // cálculo da taxa usa a data do próprio site (getSiteTodayKey), pra não
  // misturar os dois fusos na mesma conta.
  function localTodayKey() {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  }

  function addDaysToDate(baseDate, days) {
    const d = new Date(baseDate);
    d.setDate(d.getDate() + Math.round(days));
    return d;
  }

  function formatDateShort(d) {
    if (currentSettings.language === 'en') {
      return `${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')}`;
    }
    return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`;
  }

  // Diferença em dias corridos entre duas chaves "YYYY-MM-DD".
  function daysBetweenKeys(keyA, keyB) {
    const a = new Date(keyA + 'T00:00:00');
    const b = new Date(keyB + 'T00:00:00');
    return Math.round((b - a) / 86400000);
  }

  const numFromMatch = (s) => parseInt(s.replace(/,/g, ''), 10);

  // Lê o bloco "Period Totals" como fallback imediato. O valor de
  // "Total Screened" é usado diretamente como ritmo provisório quando ainda
  // não há histórico diário suficiente no coletor em background.
  function parsePeriodTotals(fullText) {
    const screenedMatch = fullText.match(/Total Screened:\s*([\d,]+)/i);
    if (!screenedMatch) return null;
    const totalScreened = numFromMatch(screenedMatch[1]);
    if (!Number.isFinite(totalScreened) || totalScreened <= 0) return null;
    return { totalScreened, rate: totalScreened };
  }

  // Lê o bloco "Overall Queue Status" a partir do texto visível da página
  // (em vez de depender de classes/ids específicos, que não temos como
  // confirmar sem o HTML real). Retorna { totalInQueue, rows, periodTotals }
  // ou null se não achar nada reconhecível (ex: layout mudou, ou não é essa
  // página).
  function parseOverallQueueSection() {
    const fullText = document.body.innerText.replace(/\s+/g, ' ');

    const totalMatch = fullText.match(/There are currently\s+([\d,]+)\s+total photos in the queue/i);
    const totalInQueue = totalMatch ? numFromMatch(totalMatch[1]) : null;

    const rowRegex = /(\d{1,2}\s+[A-Za-z]+\s+\d{4}):\s*([\d,]+)\s+total uploads\.\s*([\d,]+)\s+not yet screened\.\s*(\d+)\s+in screening\.\s*([\d,]+)\s+processed\./gi;

    const rows = [];
    let m;
    while ((m = rowRegex.exec(fullText)) !== null) {
      const key = dateLabelToKey(m[1].trim());
      if (!key) continue; // não deveria acontecer, mas não quebra o resto se acontecer
      rows.push({
        key,
        label: m[1].trim(),
        totalUploads: numFromMatch(m[2]),
        notYetScreened: numFromMatch(m[3]),
        inScreening: parseInt(m[4], 10),
        processed: numFromMatch(m[5])
      });
    }

    if (!rows.length && totalInQueue === null) return null;

    const periodTotals = parsePeriodTotals(fullText);
    return { totalInQueue, rows, periodTotals };
  }

  // A "data de hoje" pro cálculo é a mais recente que aparece na própria
  // tabela do site (não a do relógio do usuário) — garante que o dia
  // excluído da média (por estar parcial) seja realmente o dia parcial do
  // site, mesmo que o fuso horário dele esteja defasado em relação ao do
  // usuário.
  function getSiteTodayKey(rows) {
    if (!rows.length) return null;
    return rows.reduce((max, r) => (r.key > max ? r.key : max), rows[0].key);
  }

  // O ritmo principal vem de jpQueueDailyStats, coletado pelo service worker.
  // Se ainda não houver dias fechados suficientes, o fallback imediato é o
  // "Total Screened" da própria página. Os antigos históricos baseados em
  // "processed" e snapshots da fila foram removidos porque não são mais
  // necessários e podiam introduzir estimativas inconsistentes.

  // Localiza as fotos do usuário na fila ("YOUR QUEUE STATUS") e extrai,
  // de cada uma, o número de fotos à frente (campo "Position") e uma
  // referência ao <li> do "Time in Queue" — é logo abaixo dele que a
  // estimativa individual será injetada.
  //
  // Estrutura real observada no site (cada foto tem duas cópias no DOM,
  // uma pra desktop e outra pra mobile; ambas ganham o badge pra não
  // depender de qual está visível):
  //
  //   <li class="list__item">
  //     <span>Position:</span>
  //     <span><strong>6,379</strong><sup>1</sup></span>
  //   </li>
  //   <li class="list__item">
  //     <span>Date Uploaded:</span>
  //     <span><strong>Sep 4, 2026</strong></span>
  //   </li>
  //   <li class="list__item">
  //     <span>Time in Queue:</span>
  //     <span><strong>20 days 12 hours</strong></span>
  //   </li>
  function findQueueInfoRows() {
    const matches = [];
    const positionItems = document.querySelectorAll('li.list__item');

    positionItems.forEach(li => {
      const spans = li.querySelectorAll(':scope > span');
      if (spans.length < 2) return;
      const label = (spans[0].textContent || '').trim();
      if (!/^Position:/i.test(label)) return;

      // Extrai o número de <strong> dentro do segundo <span>; ignora o
      // <sup> da nota de rodapé ("¹").
      const valueEl = spans[1].querySelector('strong');
      if (!valueEl) return;
      const m = (valueEl.textContent || '').match(/(\d[\d,]*)/);
      if (!m) return;
      const ahead = numFromMatch(m[1]);
      if (!Number.isFinite(ahead)) return;

      // Localiza o <li> do "Time in Queue" no mesmo <ul> pai (é onde
      // vamos injetar a estimativa individual logo abaixo).
      const parentUl = li.parentElement;
      if (!parentUl) return;
      const siblings = parentUl.querySelectorAll(':scope > li.list__item');
      let timeLi = null;
      for (const sib of siblings) {
        const sibLabel = sib.querySelector(':scope > span');
        if (sibLabel && /^Time in Queue:/i.test((sibLabel.textContent || '').trim())) {
          timeLi = sib;
          break;
        }
      }
      if (!timeLi) return; // sem "Time in Queue" ao lado — layout mudou, não injeta

      matches.push({ rowEl: li, timeLi, ahead });
    });

    return matches;
  }

  // Formato curto para o monitor da fila. Mantém a estimativa legível
  // dentro da coluna estreita de Period Totals; as estimativas individuais
  // das fotos continuam usando formatEtaText(), que inclui a data aproximada.
  function formatEtaDurationText(days) {
    if (days == null || !Number.isFinite(days)) return null;
    const totalHours = Math.max(0, Math.round(days * 24));
    const wholeDays = Math.floor(totalHours / 24);
    const hours = totalHours % 24;

    if (wholeDays > 0 && hours > 0) {
      return currentSettings.language === 'en'
        ? `≈ ${wholeDays} day${wholeDays === 1 ? '' : 's'} ${hours}h`
        : `≈ ${wholeDays} dia${wholeDays === 1 ? '' : 's'} e ${hours}h`;
    }
    if (wholeDays > 0) {
      return currentSettings.language === 'en'
        ? `≈ ${wholeDays} day${wholeDays === 1 ? '' : 's'}`
        : `≈ ${wholeDays} dia${wholeDays === 1 ? '' : 's'}`;
    }
    return `≈ ${hours}h`;
  }

  function formatEtaText(days) {
    if (days == null || !Number.isFinite(days)) return null;
    const totalHours = Math.max(0, Math.round(days * 24));
    const wholeDays = Math.floor(totalHours / 24);
    const hours = totalHours % 24;
    const target = addDaysToDate(new Date(), totalHours / 24); // relógio local do usuário
    let duration;
    if (wholeDays > 0 && hours > 0) {
      duration = currentSettings.language === 'en'
        ? `${wholeDays} day${wholeDays === 1 ? '' : 's'} ${hours}h`
        : `${wholeDays} dia${wholeDays === 1 ? '' : 's'} e ${hours}h`;
    } else if (wholeDays > 0) {
      duration = currentSettings.language === 'en'
        ? `${wholeDays} day${wholeDays === 1 ? '' : 's'}`
        : `${wholeDays} dia${wholeDays === 1 ? '' : 's'}`;
    } else {
      duration = currentSettings.language === 'en' ? `${hours}h` : `${hours}h`;
    }
    return `≈ ${duration} (${t('aroundDate')} ${formatDateShort(target)})`;
  }

  // Formata a estimativa individual de cada foto, com data completa (dia/mês/ano)
  // e texto mais direto: "16 dias estimado (26/09/2026)".
  function formatPhotoEtaText(days) {
    if (days == null || !Number.isFinite(days)) return null;
    const totalHours = Math.max(0, Math.round(days * 24));
    const wholeDays = Math.floor(totalHours / 24);
    const hours = totalHours % 24;
    const target = addDaysToDate(new Date(), totalHours / 24);

    // Data completa com ano
    const day = String(target.getDate()).padStart(2, '0');
    const month = String(target.getMonth() + 1).padStart(2, '0');
    const year = target.getFullYear();
    const dateStr = currentSettings.language === 'en'
      ? `${month}/${day}/${year}`
      : `${day}/${month}/${year}`;

    let duration;
    if (wholeDays > 0 && hours > 0) {
      duration = currentSettings.language === 'en'
        ? `${wholeDays} day${wholeDays === 1 ? '' : 's'} ${hours}h`
        : `${wholeDays} dia${wholeDays === 1 ? '' : 's'} e ${hours}h`;
    } else if (wholeDays > 0) {
      duration = currentSettings.language === 'en'
        ? `${wholeDays} day${wholeDays === 1 ? '' : 's'}`
        : `${wholeDays} dia${wholeDays === 1 ? '' : 's'}`;
    } else {
      duration = `${hours}h`;
    }

    const estimatedLabel = currentSettings.language === 'en' ? 'estimated' : 'estimado';
    return `≈ ${duration} ${estimatedLabel} (${dateStr})`;
  }

  // Injeta (ou atualiza, se já existir) um <li> de estimativa logo após o
  // <li class="list__item"> do "Time in Queue". Usa a mesma estrutura
  // visual dos outros itens da coluna "Queue Info" (label + valor em
  // <strong>) pra ficar visualmente integrado ao site. Marca o <li>
  // injetado com uma classe própria pra não duplicar em reprocessamentos
  // (ex: troca de período no dropdown da página).
  function injectInlineEstimate(timeLi, days) {
    const text = formatPhotoEtaText(days);
    // O badge é irmão do <li> de "Time in Queue" — fica logo abaixo dele
    // no mesmo <ul>. Se já existir um nosso, reutiliza; senão cria.
    let badge = timeLi.nextElementSibling;
    if (badge && !badge.classList.contains('jp-queue-eta-badge')) badge = null;

    if (!text) {
      if (badge) badge.remove();
      return;
    }

    if (!badge) {
      badge = document.createElement('li');
      badge.className = 'list__item jp-queue-eta-badge';
      badge.innerHTML = '<span></span><span><strong></strong></span>';
      // Insere imediatamente após o <li> do "Time in Queue", mantendo a
      // ordem visual dos campos da coluna.
      timeLi.insertAdjacentElement('afterend', badge);
    }

    const spans = badge.querySelectorAll(':scope > span');
    if (spans[0]) spans[0].textContent = t('estimatedReview');
    const strong = badge.querySelector('strong');
    if (strong) strong.textContent = text;
  }

  // -----------------------------------------------------------------------
  // v1.8.6 — Histórico automático do Total Screened
  //
  // O background.js observa o contador periodicamente e guarda o maior
  // Total Screened visto em cada dia do JetPhotos. Aqui o painel só lê esse histórico.
  // Dias fechados são usados para a média; enquanto ainda não há histórico
  // fechado suficiente, o valor máximo observado do dia atual serve como
  // estimativa provisória.
  // -----------------------------------------------------------------------
  function loadQueueDailyStats() {
    const key = STORAGE_KEY_QUEUE_DAILY_STATS;
    return getExtensionStorage([key]).then(result => result?.[key] || {});
  }

  // Se o host não mantiver o service worker ativo (restrição comum em
  // navegadores móveis), usa a leitura já disponível em queue.php para
  // guardar o mesmo Total Screened que o coletor em background guardaria.
  // Assim, o histórico continua evoluindo quando a página da fila é aberta.
  async function recordQueueStatsFromPage(parsed, siteTodayKey) {
    const totalScreened = parsed?.periodTotals?.totalScreened;
    if (!Number.isFinite(totalScreened) || !siteTodayKey) return null;

    const stats = await loadQueueDailyStats();
    const now = Date.now();
    const previousKey = stats.__meta?.lastObservedDay || null;
    if (previousKey && siteTodayKey > previousKey) {
      const previous = stats[previousKey];
      if (previous && previous.maxScreened != null) {
        previous.closed = true;
        previous.closedAtMs = now;
        previous.closeReason = 'site-day-changed';
      }
    }

    const current = stats[siteTodayKey] || {
      maxScreened: 0,
      firstObservedAtMs: now,
      samples: 0,
      closed: false
    };
    current.maxScreened = Math.max(current.maxScreened || 0, totalScreened);
    current.lastObserved = totalScreened;
    current.lastObservedAtMs = now;
    current.samples = (current.samples || 0) + 1;
    current.totalInQueue = parsed.totalInQueue;
    current.closed = false;
    stats[siteTodayKey] = current;
    stats.__meta = {
      lastObservedDay: siteTodayKey,
      lastObservedAtMs: now,
      lastScreened: totalScreened,
      lastTotalInQueue: parsed.totalInQueue,
      collectorVersion: 1
    };

    await setExtensionStorage({ [STORAGE_KEY_QUEUE_DAILY_STATS]: stats });
    return { ok: true, day: siteTodayKey, totalScreened, maxScreened: current.maxScreened, totalInQueue: parsed.totalInQueue, stats };
  }

  function getDailyAnalyzedValue(stats, key) {
    const item = stats?.[key];
    if (!item) return null;
    // Total Screened é a métrica canônica do estimador.
    // O histórico diário representa o maior valor observado naquele dia.
    return Number.isFinite(item.maxScreened) ? item.maxScreened : null;
  }

  function getHistoryDays(stats) {
    return Object.keys(stats || {})
      .filter(key => key !== '__meta' && /^\d{4}-\d{2}-\d{2}$/.test(key))
      .sort();
  }

  function getClosedDailyRates(stats, excludeKey) {
    const keys = getHistoryDays(stats);
    const values = [];
    for (let i = keys.length - 1; i >= 0 && values.length < QUEUE_RATE_SAMPLE_DAYS; i--) {
      const key = keys[i];
      if (key === excludeKey) continue;
      const item = stats[key];
      if (!item?.closed) continue;
      const value = getDailyAnalyzedValue(stats, key);
      if (Number.isFinite(value) && value > 0) values.push(value);
    }
    return values;
  }

  function computeDailyTrackerRate(stats, siteTodayKey) {
    const values = getClosedDailyRates(stats, siteTodayKey);
    if (!values.length) return null;
    return {
      rate: values.reduce((sum, value) => sum + value, 0) / values.length,
      sampleSize: values.length
    };
  }

  let lastQueueRate = null; // guardado pra reaproveitar no cálculo por linha (fotos à frente / ritmo)


  // Mostra o estado do coletor automático diretamente na página do JetPhotos.
  // Isso é apenas uma interface de diagnóstico/experimental: a fonte dos
  // dados continua sendo o background.js + chrome.storage.local.
  function renderQueueTrackerSiteCard(dailyStats, siteTodayKey, parsed, collectorResult) {
    if (!isQueuePage()) return;

    const h2 = Array.from(document.querySelectorAll('h2')).find(el =>
      /Overall Queue Status/i.test(el.textContent || '')
    );
    if (!h2) return;

    const section = h2.closest('.main__section, section') || h2.parentElement;
    if (!section) return;

    // Em vez de criar um "card" com aparência de outra aplicação, o
    // monitor usa a própria coluna de Period Totals do JetPhotos.
    // Isso deixa o recurso visualmente integrado à página original.
    const grid = h2.nextElementSibling;
    const columns = grid ? Array.from(grid.children) : [];
    const totalsColumn = columns.find(col => {
      const caption = col.querySelector('table caption');
      return caption && /Period Totals/i.test(caption.textContent || '');
    }) || null;

    let card = document.getElementById('jp-site-queue-tracker');
    if (!card) {
      card = document.createElement('div');
      card.id = 'jp-site-queue-tracker';

      if (totalsColumn) {
        const totalsTable = Array.from(totalsColumn.querySelectorAll('table')).find(table => {
          const caption = table.querySelector('caption');
          return caption && /^Period Totals$/i.test((caption.textContent || '').trim());
        });
        if (totalsTable) totalsTable.classList.add('jp-plus-dark-native-table');

        if (totalsTable) {
          totalsTable.insertAdjacentElement('afterend', card);
        } else {
          totalsColumn.appendChild(card);
        }
      } else {
        // Fallback para mudanças futuras no HTML do JetPhotos.
        // Continua abaixo do bloco Overall Queue Status, sem quebrar a página.
        const firstGridChild = grid && grid.parentElement === section ? grid : null;
        if (firstGridChild) firstGridChild.insertAdjacentElement('afterend', card);
        else section.appendChild(card);
      }
    }

    const today = dailyStats[siteTodayKey] || {};
    const closedValues = getClosedDailyRates(dailyStats, siteTodayKey);
    const average = closedValues.length
      ? closedValues.reduce((sum, value) => sum + value, 0) / closedValues.length
      : null;

    // "Screened today" e "maximum observed" são o mesmo valor que nos
    // interessa no dia atual: o maior Total Screened que o coletor conseguiu
    // observar. Não mostramos os dois para evitar informação duplicada.
    const todayScreened = collectorResult?.ok
      ? collectorResult.maxScreened
      : (today.maxScreened ?? parsed?.periodTotals?.totalScreened ?? null);

    const lastObservedAt = collectorResult?.ok
      ? collectorResult.stats?.__meta?.lastObservedAtMs
      : dailyStats.__meta?.lastObservedAtMs;

    const timeText = lastObservedAt
      ? new Date(lastObservedAt).toLocaleTimeString(currentSettings.language === 'en' ? 'en-US' : 'pt-BR', {
          hour: '2-digit',
          minute: '2-digit'
        })
      : '—';

    const todayText = todayScreened != null
      ? todayScreened.toLocaleString(currentSettings.language === 'en' ? 'en-US' : 'pt-BR')
      : '—';

    const averageText = average != null
      ? `~${Math.round(average).toLocaleString(currentSettings.language === 'en' ? 'en-US' : 'pt-BR')}/${currentSettings.language === 'en' ? 'day' : 'dia'}`
      : t('collectingHistory');

    let etaText = '—';
    const rateForEta = average || todayScreened;
    if (rateForEta && parsed?.totalInQueue != null) {
      etaText = formatEtaDurationText(parsed.totalInQueue / rateForEta) || '—';
    }

    const basisText = average != null ? t('avgClosed', closedValues.length) : t('noHistoryNote');

    // O monitor fica dentro da mesma coluna/tabela do Period Totals e herda
    // diretamente a tipografia do JetPhotos. Não forçamos Roboto, Arial ou
    // outro tamanho: a ideia é que os textos tenham exatamente a mesma
    // presença visual das células nativas do site.
    card.style.cssText = `
      box-sizing:border-box;
      width:100%;
      margin-top:18px;
      color:inherit;
      font-family:inherit;
      font-size:inherit;
    `;

    card.innerHTML = `
      <table class="table table--statistics jp-plus-queue-table" style="width:100%;margin:0;table-layout:fixed;">
        <caption style="text-align:left;">${t('queueEstimate')} <span class="jp-plus-experimental">${t('experimental')}</span></caption>
        <tbody>
          <tr class="table__row jp-plus-queue-row">
            <td class="table__cell jp-plus-metric">
              <div class="jp-plus-metric-inner"><span>${t('screenedToday')}</span><strong>${todayText}</strong></div>
            </td>
            <td class="table__cell jp-plus-metric">
              <div class="jp-plus-metric-inner"><span>${t('dailyAverage')}</span><strong>${averageText}</strong></div>
            </td>
          </tr>
          <tr class="table__row">
            <td class="table__cell jp-plus-metric">
              <div class="jp-plus-metric-inner"><span>${t('estimatedQueueTime')}</span><strong>${etaText}</strong></div>
            </td>
            <td class="table__cell jp-plus-metric">
              <div class="jp-plus-metric-inner"><span>${t('lastCollection')}</span><strong>${timeText}</strong></div>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="jp-plus-queue-note">
        <span>${basisText}</span>
        <button id="jp-site-queue-tracker-refresh" type="button">${t('collectNow')}</button>
      </div>
    `;


    const styleId = 'jp-plus-queue-native-style';
    if (!document.getElementById(styleId)) {
      const style = document.createElement('style');
      style.id = styleId;
      style.textContent = `
        /* Estimativa individual por foto — fica dentro do <ul> do "Queue Info"
           de cada foto, logo abaixo do "Time in Queue". Usa exatamente a
           mesma tipografia e cores dos outros campos nativos do site
           (label e valor herdam do <li class="list__item">). */

        #jp-site-queue-tracker {
          font-family: inherit;
        }

        #jp-site-queue-tracker .jp-plus-queue-table {
          font-family: inherit;
          border-collapse: collapse;
        }

        #jp-site-queue-tracker .jp-plus-queue-table caption {
          font-family: inherit;
          font-weight: 600;
          font-size: inherit;
          line-height: normal;
          padding: 0 0 6px 0;
          text-align: left;
        }

        #jp-site-queue-tracker .jp-plus-experimental {
          font-size: 9px;
          font-weight: normal;
          opacity: .65;
          vertical-align: middle;
          margin-left: 3px;
        }

        #jp-site-queue-tracker .jp-plus-queue-table td,
        #jp-site-queue-tracker .jp-plus-metric,
        #jp-site-queue-tracker .jp-plus-metric span,
        #jp-site-queue-tracker .jp-plus-metric strong {
          font-family: inherit;
          font-size: inherit;
          line-height: normal;
        }

        #jp-site-queue-tracker .jp-plus-metric {
          width:50%;
          vertical-align:middle;
          box-sizing:border-box;
          padding:7px 9px;
        }

        #jp-site-queue-tracker .jp-plus-metric-inner {
          display:flex;
          align-items:center;
          justify-content:space-between;
          gap:6px;
          min-width:0;
          white-space:nowrap;
        }

        #jp-site-queue-tracker .jp-plus-metric span {
          min-width:0;
          overflow:hidden;
          text-overflow:ellipsis;
          white-space:nowrap;
        }

        #jp-site-queue-tracker .jp-plus-metric strong {
          flex:0 0 auto;
          white-space:nowrap;
          text-align:right;
          font-weight:700;
        }

        #jp-site-queue-tracker .jp-plus-queue-note {
          display:flex;
          align-items:center;
          justify-content:space-between;
          gap:8px;
          margin-top:7px;
          font-size:10px;
          line-height:1.35;
          color:inherit;
          opacity:.72;
        }

        #jp-site-queue-tracker .jp-plus-queue-note > span {
          min-width:0;
        }

        #jp-site-queue-tracker button {
          appearance: none;
          border: 0;
          background: transparent;
          color: inherit;
          font: inherit;
          font-size: 10px;
          text-decoration: underline;
          cursor: pointer;
          padding: 0;
          white-space: nowrap;
        }

        #jp-site-queue-tracker button:hover {
          opacity: .7;
        }

        @media (max-width: 700px) {
          #jp-site-queue-tracker .jp-plus-queue-note {
            align-items: flex-start;
            flex-direction: column;
          }
        }
      `;
      document.head.appendChild(style);
    }

    const refresh = card.querySelector('#jp-site-queue-tracker-refresh');
    if (refresh && !refresh.dataset.bound) {
      refresh.dataset.bound = '1';
      refresh.addEventListener('click', async () => {
        refresh.disabled = true;
        refresh.textContent = t('collecting');

        try {
          let result = await sendExtensionMessage({ type: 'jp-collect-queue-now' });
          if (!result?.ok) result = await recordQueueStatsFromPage(parsed, siteTodayKey);

          const fresh = await loadQueueDailyStats();
          renderQueueTrackerSiteCard(fresh, siteTodayKey, parsed, result);
        } finally {
          // O botão pode ter sido recriado durante a renderização.
          refresh.disabled = false;
          refresh.textContent = t('collectNow');
        }
      });
    }
  }

  // Estimativa GERAL (pra quem ainda não tem foto na fila, ou quer saber
  // "se eu enviar agora, quanto tempo demora"): fila total do site dividido
  // pelo ritmo real de avaliação. Usa SEMPRE o mesmo "rate" da linha acima
  // (Ritmo atual). Na v1.8.6, a prioridade é a média dos dias fechados
  // observados automaticamente; antes de existir histórico suficiente,
  // usamos o maior Total Screened observado no dia atual.
  // "processed" (verde) de cada linha, que é só o progresso parcial de um
  // lote específico e não reflete o throughput real do site.
  function computeGeneralEtaDays(totalInQueue, rate) {
    if (totalInQueue == null || rate == null || rate <= 0) return null;
    return totalInQueue / rate;
  }

  function renderQueueRate(rate, totalInQueue, errorMsg, meta) {
    lastQueueRate = rate;
    const rateEl = document.getElementById('jp-queue-rate-text');
    const generalEl = document.getElementById('jp-queue-general-eta');
    const noteEl = document.getElementById('jp-queue-note');
    if (!rateEl) return;

    if (errorMsg) {
      rateEl.textContent = errorMsg;
      if (generalEl) generalEl.textContent = '';
      if (noteEl) noteEl.textContent = '';
      return;
    }

    if (rate == null) {
      rateEl.textContent = t('buildingHistory');
      if (generalEl) generalEl.textContent = '';
      if (noteEl) noteEl.textContent = '';
      return;
    }

    let basisLabel;
    if (meta && meta.basis === 'daily_tracker') {
      basisLabel = t('rateClosed', meta.sampleSize);
    } else if (meta && meta.basis === 'daily_tracker_today') {
      basisLabel = t('rateToday');
    } else if (meta && meta.basis === 'period_totals_today') {
      basisLabel = t('ratePeriod');
    } else if (meta && meta.basis === 'snapshot') {
      basisLabel = t('rateSnapshot', meta.sampleSize);
    } else if (meta && meta.isFallback) {
      basisLabel = t('rateFallback');
    } else {
      basisLabel = '';
    }

    rateEl.innerHTML = t('currentRate', rate, basisLabel);

    if (generalEl) {
      const generalDays = computeGeneralEtaDays(totalInQueue, rate);
      const eta = formatEtaText(generalDays);
      generalEl.innerHTML = eta ? t('generalEta', eta) : '';
    }

    if (noteEl) {
      let noteText = totalInQueue != null
        ? t('queueTotal', totalInQueue)
        : '';
      if (meta && meta.timezoneDiffDays) {
        noteText += meta.timezoneDiffDays > 0 ? t('timezoneAhead', meta.timezoneDiffDays) : t('timezoneBehind', meta.timezoneDiffDays);
      }
      noteEl.textContent = noteText;
    }
  }

  // Acima desse número de fotos detectadas na fila do usuário, a lista
  // ganha rolagem própria (altura máxima fixa) em vez de esticar o painel
  // verticalmente sem limite — o JetPhotos permite até 20 fotos em fila ao
  // mesmo tempo, então no pior caso a lista inteira ainda cabe rolando.
  const QUEUE_LIST_SCROLL_THRESHOLD = 5;
  const QUEUE_LIST_MAX_HEIGHT_PX = 180;

  function renderQueuePhotoEstimates(rows) {
    // Injeta os badges de estimativa individual em cada foto — isso NÃO
    // depende do painel da extensão, vai direto no DOM do site (nos <li>
    // do "Time in Queue"). Faz primeiro porque o restante desta função
    // (a lista resumida) depende de um elemento do painel que pode não
    // existir mais.
    rows.forEach(({ timeLi, ahead }) => {
      injectInlineEstimate(timeLi, lastQueueRate != null ? ahead / lastQueueRate : null);
    });

    const listEl = document.getElementById('jp-queue-list');
    const labelEl = document.getElementById('jp-queue-list-label');
    if (!listEl) return;

    if (!rows.length) {
      if (labelEl) labelEl.style.display = 'none';
      listEl.style.cssText = 'margin-bottom:14px;';
      listEl.innerHTML = `
        <div style="font-size:12.5px; color:var(--jp-subtext); line-height:1.5;">
          ${t('noPhotosQueue')}
        </div>`;
      return;
    }

    if (labelEl) labelEl.style.display = 'block';

    // Com poucas fotos, a lista fica "solta" no painel (comportamento
    // anterior). Com muitas, vira uma caixinha com scroll — assim o
    // painel inteiro não estica pra fora da tela em fotógrafos com fila
    // cheia.
    if (rows.length > QUEUE_LIST_SCROLL_THRESHOLD) {
      listEl.style.cssText = `
        margin-bottom:14px; max-height:${QUEUE_LIST_MAX_HEIGHT_PX}px;
        overflow-y:auto; border:1px solid var(--jp-border); border-radius:12px; padding:2px 10px;
      `;
    } else {
      listEl.style.cssText = 'margin-bottom:14px;';
    }

    listEl.innerHTML = rows.map(({ ahead }) => {
      const days = lastQueueRate != null ? ahead / lastQueueRate : null;
      const eta = formatEtaText(days) || t('noRate');
      return `<div style="font-size:13px; color:var(--jp-text); padding:4px 0;">${t('photosAhead', ahead, eta)}</div>`;
    }).join('');
  }

  async function runQueueScan() {
    const parsed = parseOverallQueueSection();
    if (!parsed) {
      renderQueueRate(null, null, t('queueReadError'));
      return;
    }

    const siteTodayKey = getSiteTodayKey(parsed.rows) || localTodayKey();
    const timezoneDiffDays = daysBetweenKeys(siteTodayKey, localTodayKey());

    // Pede uma coleta imediata ao background. Assim, ao abrir queue.php,
    // o usuário não precisa esperar o próximo alarme de 10 minutos.
    let collectorResult = null;
    if (isExtensionContextAlive()) {
      try {
        collectorResult = await sendExtensionMessage({ type: 'jp-collect-queue-now' });
      } catch (_) {
        collectorResult = null;
      }
    }

    if (!collectorResult?.ok) {
      collectorResult = await recordQueueStatsFromPage(parsed, siteTodayKey);
    }

    const dailyStats = await loadQueueDailyStats();
    const trackedToday = dailyStats[siteTodayKey];
    const closedRate = computeDailyTrackerRate(dailyStats, siteTodayKey);

    const meta = { timezoneDiffDays };
    let rate;

    if (closedRate) {
      rate = closedRate.rate;
      meta.basis = 'daily_tracker';
      meta.sampleSize = closedRate.sampleSize;
      meta.isFallback = false;
    } else if (trackedToday && Number(trackedToday.maxScreened || 0) > 0) {
      rate = trackedToday.maxScreened;
      meta.basis = 'daily_tracker_today';
      meta.sampleSize = 1;
      meta.isFallback = true;
    } else if (parsed.periodTotals) {
      // Fallback imediato: se o background ainda não conseguiu salvar o
      // contador, usamos o valor que já está no DOM desta própria página.
      rate = parsed.periodTotals.rate;
      meta.basis = 'period_totals_today';
      meta.sampleSize = 1;
      meta.isFallback = true;
    } else {
      rate = null;
      meta.basis = 'unavailable';
      meta.isFallback = true;
    }

    if (collectorResult?.ok) {
      meta.lastObserved = collectorResult.totalScreened;
      meta.trackedMaxToday = collectorResult.maxScreened;
    }

    renderQueueRate(rate, parsed.totalInQueue, null, meta);

    // Mostra o monitor também dentro da própria página do JetPhotos.
    // O dado continua vindo do background; este card é apenas visual.
    const latestDailyStats = await loadQueueDailyStats();
    renderQueueTrackerSiteCard(latestDailyStats, siteTodayKey, parsed, collectorResult);

    const userRows = findQueueInfoRows();
    renderQueuePhotoEstimates(userRows);
  }

  const QUEUE_DEBOUNCE_MS = 500;
  let queueDebounceTimer = null;
  let queueScanInFlight = false;
  let queueObserver = null;

  function isJetPhotosPlusNode(node) {
    if (!(node instanceof Element)) return false;
    return node.matches('#jp-site-queue-tracker, #jp-like-widget-bubble, #jp-plus-launcher-host, .jp-queue-eta-badge') ||
      !!node.closest('#jp-site-queue-tracker, #jp-like-widget-bubble, #jp-plus-launcher-host, .jp-queue-eta-badge');
  }

  function mutationComesOnlyFromExtension(mutation) {
    const changedNodes = [
      ...Array.from(mutation.addedNodes),
      ...Array.from(mutation.removedNodes)
    ];
    if (!changedNodes.length) return isJetPhotosPlusNode(mutation.target);
    return changedNodes.every(isJetPhotosPlusNode);
  }

  async function runQueueScanSafely() {
    if (!isExtensionContextAlive() || queueScanInFlight) return;
    queueScanInFlight = true;
    try {
      await runQueueScan();
    } catch (error) {
      // Não deixe callbacks de timer/MutationObserver gerarem "Uncaught (in promise)".
      if (!isContextInvalidatedError(error)) {
        console.error('[JetPhotos+] Falha ao atualizar os dados da fila:', error);
      }
    } finally {
      queueScanInFlight = false;
    }
  }

  function scheduleQueueRefresh() {
    clearTimeout(queueDebounceTimer);
    queueDebounceTimer = setTimeout(() => { void runQueueScanSafely(); }, QUEUE_DEBOUNCE_MS);
  }

  function initQueueEstimator() {
    void runQueueScanSafely();

    // O dropdown "Show status for" pode recarregar o bloco via AJAX sem
    // navegar de página — reobservamos o DOM (com debounce) pra reagir
    // a isso, no mesmo padrão usado pro scan de curtidas.
    const target = document.querySelector('main') || document.body;
    queueObserver = new MutationObserver(mutations => {
      const hasRelevantMutation = mutations.some(mutation => !mutationComesOnlyFromExtension(mutation));
      if (hasRelevantMutation) scheduleQueueRefresh();
    });
    queueObserver.observe(target, { childList: true, subtree: true });

    // (campo de cálculo manual removido a pedido — a extensão agora só
    // mostra o ritmo geral e, quando detecta linhas na tabela "YOUR QUEUE
    // STATUS", a estimativa de cada foto, tudo automaticamente ao abrir a
    // página. Ver runQueueScan() -> renderQueueRate() / renderQueuePhotoEstimates())

    const refreshBtn = document.getElementById('jp-queue-refresh-btn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', () => {
        const icon = refreshBtn.querySelector('svg');
        if (icon) {
          icon.classList.remove('jp-refresh-spin');
          void icon.getBoundingClientRect();
          icon.classList.add('jp-refresh-spin');
        }
        void runQueueScanSafely();
      });
    }
  }
  // >>> FIM DO BLOCO EXPERIMENTAL: ESTIMADOR DE FILA <<<
  // =======================================================================

  let observerRef = null;
  let observeTarget = null;

  // =======================================================================
  // MOBILE SELECT ENHANCER
  // -----------------------------------------------------------------------
  // Na página de upload (/addphotos/), o site usa Chosen.js que no PC cria
  // um dropdown com busca, mas no mobile desabilita e usa o <select> nativo.
  // Com 1210 fabricantes ou 307 países, rolar manualmente é inviável.
  // Este enhancer substitui esses selects por um input com autocomplete
  // otimizado pra toque: campo grande, opções com altura de 44px, filtro
  // em tempo real, e dispara change no <select> original pra manter os
  // selects dependentes funcionando (aeroporto depende de país, modelo
  // depende de fabricante, etc).
  // =======================================================================

  function isAddPhotosPage() {
    return location.pathname.startsWith('/addphotos/');
  }

  function isMobileDevice() {
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0 || window.innerWidth <= 1024;
  }

  // IDs dos selects que o enhancer vai melhorar. Incluídos tanto os que
  // têm centenas de opções quanto os dinâmicos que podem crescer.
  const ENHANCER_TARGET_IDS = [
    'modal-correct-info-location-country',
    'modal-correct-info-location-airport',
    'modal-correct-info-aircraft-manu',
    'modal-correct-info-aircraft-type',
    'modal-correct-info-aircraft-model',
    'modal-correct-info-airline-category',
    'modal-correct-info-airline-airline',
    'modal-correct-info-camera',
    'modal-correct-info-lens',
    'modal-hot-photo-select',
  ];

  function injectMobileEnhancerStyles() {
    if (document.getElementById('jp-mobile-enhancer-style')) return;
    const style = document.createElement('style');
    style.id = 'jp-mobile-enhancer-style';
    style.textContent = `
      .jp-enhancer-wrapper {
        position: relative;
        width: 100%;
      }
      .jp-enhancer-input {
        width: 100%;
        box-sizing: border-box;
        padding: 8px 10px;
        font-size: 14px;
        border: 1px solid #c8c8c8;
        border-radius: 6px;
        background: #fff;
        color: #222;
        outline: none;
        -webkit-appearance: none;
        appearance: none;
      }
      .jp-enhancer-input:focus {
        border-color: #2c94e8;
        box-shadow: 0 0 0 2px rgba(44,148,232,.2);
      }
      .jp-enhancer-input::placeholder {
        color: #999;
      }
      .jp-enhancer-dropdown {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        max-height: 260px;
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
        background: #fff;
        border: 1px solid #c8c8c8;
        border-top: none;
        border-radius: 0 0 8px 8px;
        box-shadow: 0 6px 18px rgba(0,0,0,.18);
        z-index: 1000010;
      }
      .jp-enhancer-dropdown.jp-enhancer-open {
        display: block;
      }
      .jp-enhancer-option {
        padding: 12px 14px;
        font-size: 15px;
        color: #222;
        cursor: pointer;
        border-bottom: 1px solid #f0f0f0;
        min-height: 44px;
        box-sizing: border-box;
        display: flex;
        align-items: center;
      }
      .jp-enhancer-option:last-child {
        border-bottom: none;
      }
      .jp-enhancer-option:active,
      .jp-enhancer-option.jp-enhancer-active {
        background: #e8f4fd;
      }
      .jp-enhancer-option.jp-enhancer-selected {
        background: #d4edfc;
        font-weight: 600;
      }
      .jp-enhancer-no-results {
        padding: 14px;
        font-size: 14px;
        color: #999;
        text-align: center;
      }
      .jp-enhancer-spinner {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 2px solid #e0e0e0;
        border-top-color: #666;
        border-radius: 50%;
        animation: jp-enhancer-spin 0.6s linear infinite;
      }
      @keyframes jp-enhancer-spin {
        to { transform: rotate(360deg); }
      }
      .jp-enhancer-counter {
        padding: 8px 12px;
        font-size: 11px;
        color: #888;
        text-align: center;
        background: #f7f7f7;
        border-bottom: 1px solid #eee;
        position: sticky;
        top: 0;
        z-index: 2;
      }
      .jp-enhancer-group-label {
        padding: 8px 14px 4px;
        font-size: 11px;
        font-weight: 700;
        color: #666;
        text-transform: uppercase;
        letter-spacing: .5px;
        background: #f7f7f7;
        position: sticky;
        top: 0;
      }
      /* Modo escuro do site */
      html.jp-site-dark-active .jp-enhancer-input {
        background: #292929;
        color: #eee;
        border-color: #505050;
      }
      html.jp-site-dark-active .jp-enhancer-input::placeholder { color: #888; }
      html.jp-site-dark-active .jp-enhancer-input:focus { border-color: #4299dc; }
      html.jp-site-dark-active .jp-enhancer-dropdown {
        background: #292929;
        border-color: #505050;
      }
      html.jp-site-dark-active .jp-enhancer-option {
        color: #eee;
        border-bottom-color: #3a3a3a;
      }
      html.jp-site-dark-active .jp-enhancer-option:active,
      html.jp-site-dark-active .jp-enhancer-option.jp-enhancer-active { background: #1a4a6e; }
      html.jp-site-dark-active .jp-enhancer-option.jp-enhancer-selected { background: #1a5a8e; }
      html.jp-site-dark-active .jp-enhancer-group-label { background: #333; color: #aaa; }
      html.jp-site-dark-active .jp-enhancer-no-results { color: #777; }
      html.jp-site-dark-active .jp-enhancer-counter { background: #333; color: #888; border-bottom-color: #444; }
      html.jp-site-dark-active .jp-enhancer-spinner {
        border-color: #444;
        border-top-color: #aaa;
      }
      /* Esconde o select nativo e o Chosen container no mobile */
      .jp-enhancer-hidden-native {
        display: none !important;
      }
    `;
    document.head.appendChild(style);
  }

  // Lê todas as opções de um <select> (incluindo <optgroup>) e retorna
  // um array de { value, text, group }.
  function getSelectOptions(select) {
    const options = [];
    Array.from(select.children).forEach(child => {
      if (child.tagName === 'OPTGROUP') {
        const groupName = child.label || '';
        Array.from(child.children).forEach(opt => {
          if (opt.tagName === 'OPTION') {
            options.push({ value: opt.value, text: opt.textContent.trim(), group: groupName });
          }
        });
      } else if (child.tagName === 'OPTION') {
        options.push({ value: child.value, text: child.textContent.trim(), group: '' });
      }
    });
    return options;
  }

  // Cria o autocomplete pro select. O select original fica escondido;
  // o Chosen container (se existir) também. Nosso wrapper fica no lugar.
  function enhanceSelect(select) {
    // Não duplica se já foi enhanced
    if (select.dataset.jpEnhanced === '1') return;

    select.dataset.jpEnhanced = '1';

    // Pega placeholder do data-placeholder ou do primeiro option
    const placeholder = select.dataset.placeholder
      || select.querySelector('option')?.textContent?.trim()
      || 'Select...';

    // Esconde o select original
    select.style.display = 'none';

    // Esconde o Chosen container (irmão do select)
    const chosenContainer = select.parentElement?.querySelector('.chosen-container');
    if (chosenContainer) chosenContainer.style.display = 'none';

    // Cria o wrapper
    const wrapper = document.createElement('div');
    wrapper.className = 'jp-enhancer-wrapper';

    // Input de busca
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'jp-enhancer-input';
    input.placeholder = placeholder;
    input.autocomplete = 'off';
    input.setAttribute('autocapitalize', 'off');
    input.setAttribute('autocorrect', 'off');

    // Mostra o texto da opção selecionada no input
    const selectedOption = select.querySelector(`option[value="${CSS.escape(select.value)}"]`);
    if (selectedOption && selectedOption.value && selectedOption.value !== '-1') {
      input.value = selectedOption.textContent.trim();
    }

    // Dropdown
    const dropdown = document.createElement('div');
    dropdown.className = 'jp-enhancer-dropdown';

    wrapper.appendChild(input);
    wrapper.appendChild(dropdown);

    // Insere o wrapper no lugar do select (depois dele)
    select.parentElement.appendChild(wrapper);

    // Estado
    let allOptions = getSelectOptions(select);
    let isOpen = false;
    const MAX_RENDERED = 50; // Reduzido de 80 pra 50 — mais rápido no mobile
    let renderTimer = null;

    function renderDropdown(filter) {
      // Cancela render anterior se ainda estiver pendente
      if (renderTimer) { clearTimeout(renderTimer); renderTimer = null; }

      const query = (filter || '').toLowerCase().trim();

      // Mostra loading imediatamente
      dropdown.innerHTML = `<div class="jp-enhancer-no-results"><div class="jp-enhancer-spinner"></div></div>`;

      // Renderiza assincronamente pra não bloquear a thread principal
      renderTimer = setTimeout(() => {
        renderTimer = null;
        dropdown.innerHTML = '';

        // Pré-filtra com text lowercase cacheado (evita toLowerCase repetido)
        const filtered = allOptions.filter(opt => {
          if (!opt.value && !opt.text) return false;
          if (query && (opt.value === '-1' || opt.value === '')) return false;
          if (!query) return true;
          return opt.text.toLowerCase().includes(query);
        });

        if (!filtered.length) {
          const noResults = document.createElement('div');
          noResults.className = 'jp-enhancer-no-results';
          noResults.textContent = currentSettings.language === 'en' ? 'No results found' : 'Nenhum resultado encontrado';
          dropdown.appendChild(noResults);
          return;
        }

        const toRender = filtered.slice(0, MAX_RENDERED);
        const hasMore = filtered.length > MAX_RENDERED;

        // Usa DocumentFragment pra inserir tudo de uma vez (mais rápido que
        // appendChild individual, que força reflow a cada elemento)
        const fragment = document.createDocumentFragment();

        if (hasMore) {
          const counter = document.createElement('div');
          counter.className = 'jp-enhancer-counter';
          counter.textContent = currentSettings.language === 'en'
            ? `Showing ${MAX_RENDERED} of ${filtered.length} — type to filter`
            : `Mostrando ${MAX_RENDERED} de ${filtered.length} — digite para filtrar`;
          fragment.appendChild(counter);
        }

        let currentGroup = null;
        toRender.forEach(opt => {
          if (opt.group && opt.group !== currentGroup) {
            currentGroup = opt.group;
            const groupLabel = document.createElement('div');
            groupLabel.className = 'jp-enhancer-group-label';
            groupLabel.textContent = opt.group;
            fragment.appendChild(groupLabel);
          }

          const optionEl = document.createElement('div');
          optionEl.className = 'jp-enhancer-option';
          if (opt.value === select.value) optionEl.classList.add('jp-enhancer-selected');
          optionEl.textContent = opt.text;
          // Usa um único listener com delegation (mais leve que 50 listeners individuais)
          optionEl.dataset.value = opt.value;
          optionEl.dataset.text = opt.text;
          fragment.appendChild(optionEl);
        });

        dropdown.appendChild(fragment);
      }, 10); // setTimeout mínimo pra liberar a thread antes de renderizar
    }

    // Event delegation: um único listener no dropdown em vez de um por opção
    dropdown.addEventListener('click', (e) => {
      const optionEl = e.target.closest('.jp-enhancer-option');
      if (!optionEl) return;
      const opt = { value: optionEl.dataset.value, text: optionEl.dataset.text };
      selectOption(opt);
    });
    dropdown.addEventListener('touchstart', (e) => {
      const optionEl = e.target.closest('.jp-enhancer-option');
      if (optionEl) optionEl.classList.add('jp-enhancer-active');
    }, { passive: true });
    dropdown.addEventListener('touchend', (e) => {
      const optionEl = e.target.closest('.jp-enhancer-option');
      if (optionEl) optionEl.classList.remove('jp-enhancer-active');
    }, { passive: true });

    function selectOption(opt) {
      // Atualiza o select original
      select.value = opt.value;
      input.value = opt.text;
      closeDropdown();
      // Dispara change pro site atualizar selects dependentes
      // (aeroporto depende de país, modelo depende de fabricante, etc)
      select.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function openDropdown() {
      if (select.disabled) return;
      isOpen = true;
      renderDropdown(input.value);
      dropdown.classList.add('jp-enhancer-open');
    }

    function closeDropdown() {
      isOpen = false;
      dropdown.classList.remove('jp-enhancer-open');
      // Restaura o texto da opção selecionada
      const selected = allOptions.find(o => o.value === select.value);
      if (selected) input.value = selected.text;
      else if (!select.value || select.value === '-1') input.value = '';
    }

    // Eventos do input
    input.addEventListener('focus', () => {
      openDropdown();
    });

    // Debounce no filtro: espera 150ms antes de renderizar, pra não
    // travar o celular filtrando a cada tecla pressionada.
    let filterTimer = null;
    input.addEventListener('input', () => {
      if (filterTimer) clearTimeout(filterTimer);
      filterTimer = setTimeout(() => {
        renderDropdown(input.value);
        if (!isOpen) openDropdown();
      }, 150);
    });

    // Fecha ao clicar fora
    document.addEventListener('click', (e) => {
      if (!wrapper.contains(e.target)) {
        closeDropdown();
      }
    });

    // Re-renderiza quando o select é desabilitado/habilitado (muda estado
    // de selects dependentes após seleção do pai)
    const selectObserver = new MutationObserver(() => {
      if (select.disabled) {
        input.disabled = true;
        input.placeholder = placeholder;
        input.value = '';
        closeDropdown();
      } else {
        input.disabled = false;
      }
      // Recarrega as opções (podem ter sido adicionadas via AJAX)
      allOptions = getSelectOptions(select);
      if (isOpen) renderDropdown(input.value);
      // Atualiza o texto do input com a opção selecionada
      const selected = allOptions.find(o => o.value === select.value);
      if (selected && selected.value && selected.value !== '-1') {
        input.value = selected.text;
      }
    });
    selectObserver.observe(select, { childList: true, attributes: true, subtree: true });

    // Mantém o input sincronizado quando o select é atualizado externamente
    // (autofill do site, outro script, etc). O autofill nem sempre dispara
    // o evento 'change', então fazemos polling do valor do select.
    let lastSelectValue = select.value;

    function syncInputFromSelect() {
      if (select.value === lastSelectValue) return;
      lastSelectValue = select.value;
      // Recarrega opções (podem ter sido adicionadas via AJAX pelo autofill)
      allOptions = getSelectOptions(select);
      const selected = allOptions.find(o => o.value === select.value);
      if (selected && selected.value && selected.value !== '-1') {
        input.value = selected.text;
      } else if (!select.value || select.value === '-1') {
        input.value = '';
      }
    }

    select.addEventListener('change', syncInputFromSelect);

    // Polling a cada 500ms — pega mudanças que não disparam 'change'
    // (autofill do site, scripts externos, etc)
    const pollInterval = setInterval(() => {
      // Para de fazer polling se o select foi removido do DOM
      if (!document.contains(select)) {
        clearInterval(pollInterval);
        return;
      }
      syncInputFromSelect();
    }, 500);
  }

  function initMobileSelectEnhancer() {
    // Só ativa no mobile/tablet
    if (!isMobileDevice()) return;

    // Espera o DOM carregar completamente (o Chosen.js precisa ter
    // rodado primeiro pra a gente poder esconder o container dele)
    function tryEnhance() {
      injectMobileEnhancerStyles();
      let enhanced = 0;
      ENHANCER_TARGET_IDS.forEach(id => {
        const select = document.getElementById(id);
        if (select && select.dataset.jpEnhanced !== '1') {
          enhanceSelect(select);
          enhanced++;
        }
      });
      return enhanced;
    }

    // Tenta imediatamente; se os selects ainda não existem, tenta de novo
    // em intervalos curtos (o Chosen pode demorar pra inicializar).
    if (tryEnhance() === 0) {
      let attempts = 0;
      const retry = setInterval(() => {
        attempts++;
        if (tryEnhance() > 0 || attempts >= 20) {
          clearInterval(retry);
        }
      }, 300);
    }
  }

  async function init() {
    currentSettings = await getSettings();

    applySiteDarkMode(currentSettings.siteDarkMode);
    // O tema (classe no <html> + CSS) já está valendo aqui — seguro revelar
    // a página agora, sem flash do tema claro original. Se o modo escuro
    // estiver desligado, isso é um no-op (a classe de preload nunca foi
    // adicionada).
    removePreloadHide();

    // A extensão agora carrega em TODAS as páginas do jetphotos.com (veja
    // o manifest.json). O header é global; ferramentas contextuais ficam
    // separadas da navegação para não transformar o menu em um painel.
    // isQueue tem prioridade (queue.php também "bate" em getPageContextLabel,
    // mas não tem botões de curtir — são corpos mutuamente exclusivos).
    // Fora das duas, o painel abre compacto e serve apenas como acesso ao
    // JetPhotos+; o estimador mantém suas configurações próprias em queue.php.
    const isQueue = isQueuePage();
    const isPhotoContext = !isQueue && (Boolean(getPageContextLabel()) || document.querySelectorAll('img[alt="Like"], img[title="Like"]').length > 0);

    const panelBuilt = buildPanel(isPhotoContext, isQueue);
    if (panelBuilt === false) {
      let attempts = 0;
      const retryHeader = setInterval(() => {
        attempts++;
        if (findHeaderIntegrationTarget() || attempts >= 30) {
          clearInterval(retryHeader);
          if (attempts < 30 && !panelEl) {
            const rebuilt = buildPanel(isPhotoContext, isQueue);
            if (rebuilt !== false) {
              // O submenu permanece fechado até hover/foco.
            }
          }
        }
      }, 200);
      return;
    }

    // O submenu é próprio da extensão e aparece em todas as páginas por
    // hover/foco no JETPHOTOS+. Contém atalhos de novidades, suporte, sobre e configurações.
    // O conteúdo de curtidas fica separado, no canto inferior direito, nas
    // páginas que realmente possuem fotos com ação de Like.

    // A bolha só passa a ser funcional quando encontra fotos com ação de
    // Like. Em páginas sem fotos ela nem é criada (ver buildPanel); o toque
    // nela chama runLikeAllBatch() direto.
    if (isPhotoContext) {
      wireLikeSync();
      scheduleRefresh();
      // do <body> inteiro, pra reduzir o volume de mutações capturadas
      // (o body inteiro inclui spinners, menus, tudo). Se não achar uma
      // área específica, cai no body mesmo — com debounce isso já é seguro.
      observeTarget =
        document.querySelector('#search-results') ||
        document.querySelector('.search-results') ||
        document.querySelector('main') ||
        document.body;

      observerRef = new MutationObserver(() => scheduleRefresh());
      observerRef.observe(observeTarget, { childList: true, subtree: true });
    }

    // [EXPERIMENTAL] Estimador de fila: só roda em queue.php, com o recurso
    // ligado (padrão: ligado — toggle em Configurações > Experimental), e é
    // independente do bloco de curtidas acima (nunca rodam juntos na mesma
    // página). Se o recurso estiver desligado, buildPanel() já não criou
    // nenhum dos elementos que initQueueEstimator() espera encontrar, então
    // nem tentamos chamá-la.
    if (isQueue && currentSettings.queueEstimatorEnabled) {
      initQueueEstimator();
    }

    // Mobile Select Enhancer: na página de upload (/addphotos/), melhora os
    // selects gigantes (fabricante, país, aeroporto, etc) com um autocomplete
    // mobile-friendly. No PC o site já usa Chosen.js que funciona bem; no
    // mobile o Chosen desabilita e sobra o <select> nativo com centenas de
    // opções pra rolar manualmente — esse enhancer resolve isso.
    if (isAddPhotosPage()) {
      initMobileSelectEnhancer();
    }

  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
